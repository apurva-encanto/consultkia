<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
	
  
    Route::post('register', [App\Http\Controllers\API\UserController::class, 'register']);
    Route::post('checkUser', [App\Http\Controllers\API\UserController::class, 'checkUser']);
    Route::post('login', [App\Http\Controllers\API\UserController::class, 'login']); 
    Route::post('otpVerified', [App\Http\Controllers\API\UserController::class, 'otpVerified']); 
    Route::get('getLawyerDeatils/{id?}', [App\Http\Controllers\API\UserController::class, 'getLawyerDeatils']);
    Route::get('lawyerDetails/{id?}', [App\Http\Controllers\API\UserController::class, 'lawyerDetails']);
    
    Route::post('addEditState', [App\Http\Controllers\API\AdminController::class, 'addEditState']);
    Route::get('stateList', [App\Http\Controllers\API\AdminController::class, 'stateList']);
    Route::get('courtList', [App\Http\Controllers\API\AdminController::class, 'courtList']);
    Route::get('getoffer/{type?}', [App\Http\Controllers\API\UserController::class, 'getoffer']);
    Route::get('languageList', [App\Http\Controllers\API\AdminController::class, 'languageList']);
    Route::post('addEditPractice', [App\Http\Controllers\API\AdminController::class, 'addEditPractice']);
    Route::get('practiceList', [App\Http\Controllers\API\AdminController::class, 'practiceList']);
    Route::get('blogList', [App\Http\Controllers\API\AdminController::class, 'blogList']);
    Route::get('lawyersList/{type?}', [App\Http\Controllers\API\UserController::class, 'lawyersList']);
    Route::get('lawyerByArea/{type?}', [App\Http\Controllers\API\UserController::class, 'lawyerByArea']);
    Route::post('reviewlist', [App\Http\Controllers\API\ReviewController::class, 'reviewlist']);
    Route::get('reviewscount/{id?}', [App\Http\Controllers\API\ReviewController::class, 'reviewscount']);
    Route::get('blogDetails/{id?}', [App\Http\Controllers\API\AdminController::class, 'blogDetails']);
    Route::get('checkavailability/{id?}', [App\Http\Controllers\API\AvailabilityController::class, 'checkavailability']);
    Route::get('guidelines/{usertype?}/{type?}', [App\Http\Controllers\API\AdminController::class, 'guidelines']);

    Route::group(['middleware'=>['Login']],function(){
	    Route::post('addQuidelines', [App\Http\Controllers\API\AdminController::class, 'addQuidelines']);
	    Route::get('getprofile', [App\Http\Controllers\API\UserController::class, 'getprofile']);
	    Route::post('updateProfile', [App\Http\Controllers\API\UserController::class, 'updateProfile']);
	        
	    Route::post('addEditLanguage', [App\Http\Controllers\API\AdminController::class, 'addEditLanguage']);
	    Route::post('addEditCourt', [App\Http\Controllers\API\AdminController::class, 'addEditCourt']);
	    Route::post('updateSequencing', [App\Http\Controllers\API\AdminController::class, 'updateSequencing']);
	    Route::post('addEditBlog', [App\Http\Controllers\API\AdminController::class, 'addEditBlog']);
	    Route::post('addReview', [App\Http\Controllers\API\ReviewController::class, 'addReview']);
	    Route::post('addavailability', [App\Http\Controllers\API\AvailabilityController::class, 'addavailability']);
	    Route::post('favoriteUnfavorite', [App\Http\Controllers\API\UserController::class, 'favoriteUnfavorite']);
	    Route::get('favoriteUnfavoriteList', [App\Http\Controllers\API\UserController::class, 'favoriteUnfavoriteList']);
	    Route::get('getAllOrders/{id?}', [App\Http\Controllers\API\OrderController::class, 'getAllOrders']);
	    Route::get('getCallhistory', [App\Http\Controllers\API\OrderController::class, 'getCallhistory']);
	    Route::get('callDetail/{id?}', [App\Http\Controllers\API\OrderController::class, 'callDetail']);
	    Route::post('addCallRecord', [App\Http\Controllers\API\OrderController::class, 'addCallRecord']);
	    Route::get('transactionList/{type?}', [App\Http\Controllers\API\TransactionController::class, 'transactionList']);
	    Route::get('myReviews', [App\Http\Controllers\API\ReviewController::class, 'myReviews']);

	    Route::get('logout', [App\Http\Controllers\API\UserController::class, 'logout']);

});
