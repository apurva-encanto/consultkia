<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Validator;
use Session;
use Auth;
use Twilio\Rest\Client;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Rate;
use App\Models\Pet;
use App\Models\Review;
use App\Models\Transaction;

class TransactionController extends ApiController
{
    public function __construct(){
        Auth::shouldUse('api');
    }

    public function transactionList($type=''){
       
        $user=Auth::user();
        if(!empty($user)){
            // return $user;

            if($user->user_type==1){
                 // type 1-paid,2-aaded to wallet,3-refrence earn,else all
                if($type==1){
                    $getAllTransaction=Transaction::with('lawyerDetails')->where('from',$user->id)->whereIn('sender_type',['2','5'])->get();
                    $msg="All Pay Transactions";
                }elseif($type==2){
                    $getAllTransaction=Transaction::with('lawyerDetails')->where('to',$user->id)->whereIn('reciever_type',['1','4'])->get();
                    $msg="All Received Transactions";
                }elseif($type==3){
                    $getAllTransaction=Transaction::with('lawyerDetails')->where('to',$user->id)->whereIn('reciever_type',['1'])->get();
                    $msg="All Earning Transactions";
                }else{
                    $getAllTransaction=Transaction::with('lawyerDetails')->where('to',$user->id)->orWhere('from',$user->id)->get();
                    $msg="All Transactions";
                }

                if(sizeof($getAllTransaction)){
                    foreach ($getAllTransaction as $row) {
                        // return $row->sender_type;
                        if($row->sender_type == "2" || $row->sender_type == "5"){
                            if($row->sender_type == "2"){
                                $row->title="Paid For Order";
                            }else{
                                $row->title="Wallet Withdrawal";
                            }
                            $row->type=0;
                        }else{
                            if($row->reciever_type=="1"){
                                $row->title="Refrence earning";
                            }else{
                                $row->title="Add To Wallet";
                            }
                           $row->type=1;
                        }
                        $asiaKolkataDateTime = $row->created_at;
                        $carbonAsiaKolkata = Carbon::createFromFormat('Y-m-d H:i:s', $asiaKolkataDateTime, 'Asia/Kolkata');
                        $carbonUtc = $carbonAsiaKolkata->setTimezone('UTC');
                        $carbonUtc = Carbon::createFromFormat('Y-m-d H:i:s', $row->created_at);
                        $carbonAsiaKolkata = $carbonUtc->setTimezone('Asia/Kolkata');

                        $date = Carbon::parse($carbonAsiaKolkata)->format('M-d g:i A');
                        // return $date;
                        $row->time=$date;
                        $data[]=$row;
                        unset($row->lawyerDetails);
                        unset($row->updated_at);
                        unset($row->from);
                        unset($row->to);
                        unset($row->sender_type);
                        unset($row->created_at);
                        unset($row->reciever_type);

                    }
                    return response()->json(["status" => 200,"success"=>true,"message"=>$msg,'data'=>$data]);
                }else{
                    return response()->json(["status" => 400,"success"=>false,"message"=>"Transactions not found"]);
                }
                
            }else{
                 // type 1-withdrawal,2-received to wallet,3-refrence earn,else all
                if($type==1){
                    $getAllTransaction=Transaction::with('userDetails')->where('from',$user->id)->where('sender_type','5')->get();
                    // return $getAllTransaction;
                    $msg="All Withdrawal Transactions.";
                }elseif($type==2){
                    $getAllTransaction=Transaction::with('userDetails')->where('to',$user->id)->whereIn('reciever_type',['3'])->get();
                    $msg="All Received Transactions.";
                }elseif($type==3){
                    $getAllTransaction=Transaction::with('userDetails')->where('to',$user->id)->whereIn('reciever_type',['1'])->get();
                    $msg="All Earning Transactions.";
                }else{
                    $getAllTransaction=Transaction::with('userDetails')->where('to',$user->id)->orWhere('from',$user->id)->get();
                    $msg="All Transactions";
                }
            }
              
                if(sizeof($getAllTransaction)){
                    foreach ($getAllTransaction as $row) {                        
                        if($row->sender_type == "5"){                            
                            $row->title="Wallet Withdrawal";                            
                            $row->type=0;
                        }
                        if($row->reciever_type == "1" || $row->reciever_type == "3" || $row->reciever_type == "4"){
                            
                            if($row->reciever_type == "1"){
                                $row->title="Refrence Earning";
                            }elseif($row->reciever_type == "3"){
                                $row->title="Received For Order";
                            }else{
                                $row->title="Add To Wallet";
                            }
                            $row->type=1;
                        }
                           
                        
                        $asiaKolkataDateTime = $row->created_at;
                        $carbonAsiaKolkata = Carbon::createFromFormat('Y-m-d H:i:s', $asiaKolkataDateTime, 'Asia/Kolkata');
                        $carbonUtc = $carbonAsiaKolkata->setTimezone('UTC');
                        $carbonUtc = Carbon::createFromFormat('Y-m-d H:i:s', $row->created_at);
                        $carbonAsiaKolkata = $carbonUtc->setTimezone('Asia/Kolkata');

                        $date = Carbon::parse($carbonAsiaKolkata)->format('M-d g:i A');
                        // return $date;
                        $row->time=$date;
                        $data[]=$row;
                        unset($row->userDetails);
                        unset($row->updated_at);
                        unset($row->from);
                        unset($row->to);
                        unset($row->sender_type);
                        unset($row->created_at);
                        unset($row->reciever_type);

                    }
                    return response()->json(["status" => 200,"success"=>true,"message"=>$msg,'data'=>$data]);
                }else{
                    return response()->json(["status" => 400,"success"=>false,"message"=>"Transactions not found"]);
                }


        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You're not authorized"]);
        }
    }
   
}
