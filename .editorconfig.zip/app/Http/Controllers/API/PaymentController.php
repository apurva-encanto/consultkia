<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Http\JsonResponse;
use Validator;
use Session;
use Auth;
use Carbon\Carbon;
use App\Models\Payment;
use App\Models\OrderDetail;
use App\Models\DefaultCard;
use App\Models\Order;
use App\Models\User;
use App\Models\Appointment;
use App\Models\Ticketlist;
use App\Models\Notification;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use App\Models\Slot;
use App\Models\Rate;
use App\Models\Rvndetail;
use App\Models\Product;
use App\Models\Cart;
use Stripe;
use Stripe\StripeClient;

class PaymentController extends ApiController
{
    private $stripes;

    public function __construct()
    {        
       
        Auth::shouldUse('api');
       
    
    }
   


    public function addCardNo(Request $request)
    {

    
    }

    public function fetchCard()
    {
        $user = Auth::user();
    }

    public function  deleteCard(Request $request)
    {
        $user = Auth::user();
    } 

    public function setDefaultCard($card=''){
        $user=Auth::user();
        if(!empty($user)){
            $check=DefaultCard::where('user_id',$user->id)->first();
            if(!empty($check)){
                $updatestatus=DefaultCard::where('user_id',$user->id)->update([
                    'card_id'=>$card]);
                if($updatestatus){
                    return response()->json(["status" => 200, "success"=> true, "message" =>"Card set as default"]); 
                }else{
                    return response()->json(["status" => 400, "success"=> false, "message" =>"failed try again"]);
                }
            }else{
                $status=new DefaultCard ();
                $status->user_id=$user->id;
                $status->card_id=$card;
                $query=$status->save();
                if($query){
                    return response()->json(["status" => 200, "success"=> true, "message" =>"Card set as default"]); 
                }else{
                    return response()->json(["status" => 400, "success"=> false, "message" =>"failed try again"]);
                }
            }
        }

    }
    
    public function getDefaultCard(){
        $user=Auth::user();
        if(!empty($user)){
            $check=DefaultCard::select('card_id')->where('user_id',$user->id)->first();
            if(!empty($check)){

               return response()->json(["status" => 200, "success"=> true, "message" =>"Default Card",'data'=>$check->card_id]); 
            }else{
                return response()->json(["status" => 400, "success"=> false, "message" =>"Card not found"]);
            }
        
        }else{
             return response()->json(["status" => 400, "success"=> false, "message" =>"You're not authorized "]);
        }

    }


    public function createCustomer(){    

        $curl = curl_init();
        curl_setopt_array($curl, [
          CURLOPT_URL => "https://api.juspay.in/customers",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "content-type: application/x-www-form-urlencoded",
            "x-merchantid: merchant_id"
          ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          echo $response;
        }
    
    }


    
}