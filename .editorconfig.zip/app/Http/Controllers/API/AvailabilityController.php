<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Auth;
use Validator;
use App\Models\Availability;
use App\Models\AvailabilityTime;
use App\Models\LawyerDetail;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use App\Models\Schedule;
use App\Models\CallChatHistory;
use App\Models\Slot;
use DateTime;
class AvailabilityController extends ApiController
{
    public function __construct()
    {
        Auth::shouldUse('api');

    }
        /* add availability start*/

        public function addavailability(Request $request){
            $validator = Validator::make($request->all(),[
                'is_chat'=>"required",
                'is_call'=>"required",
                'call_charge'=>"required",
                'chat_charge'=>"required",
                'availability' => 'required',
            ]);

            if($validator->fails()){
                return response()->json(["status" => 400,"success"=>false, "message" => $validator->messages()->first()]);
            }   
            $user=Auth::user(); 
            $checkuser=LawyerDetail::where('user_id',$user->id)->first();
            if(!empty($checkuser)){
                $updateDetail=LawyerDetail::find($checkuser->id);
                $updateDetail->is_chat=$request->is_chat;
                $updateDetail->is_call=$request->is_call;
                $updateDetail->call_charge=$request->call_charge;
                $updateDetail->chat_charge=$request->chat_charge;
                $updateQuery=$updateDetail->save();
                if($updateQuery==true){
                    if($request->is_call==1 || $request->is_call==1){
                        $callchathistory=new CallChatHistory();
                        if($request->is_call==1){
                            $callchathistory->calls=$request->call_charge;
                        }
                        if($request->is_call==1){
                            $callchathistory->chats=$request->chat_charge;
                        }
                        $callchathistory->lawyer_id=$user->id;
                        $querycallchathistory=$callchathistory->save();
                    
                    }
                    

                    $query='';
                    foreach($request->availability as $value){                  
                    $check=Availability::where(['user_id'=>$user->id,'day_id'=>$value['day_id']])->first();
                        if(!empty($check)){
                            if($value['status']==1){  
                                $update=AvailabilityTime::where(['availability_id'=>$check->id])->update(['status'=>'0']);
                                foreach($value['time'] as $row){   
                                    $save=new AvailabilityTime();
                                    $save->availability_id=$check->id;
                                    $save->from =$row['from'];
                                    $save->to=$row['to'];
                                    $query= $save->save(); 
                                }
                            }

                        }else{
                            if($value['status']==1){   
                                $check= new Availability();
                                $check->user_id=$user->id;
                                $check->day_id=$value['day_id'];
                                $check->status=$value['status'];                        
                                $query=$check->save();
                                foreach($value['time'] as $row){                            
                                    $checkAvailability=AvailabilityTime::where(['availability_id'=>$check->id,"from" => $row['from'],"to" => $row['to']])->first();              
                                    if(!empty($checkAvailability)){
                                        $query=AvailabilityTime::where(['availability_id'=>$checkAvailability->id])->update([
                                            "from" =>$row['from'],
                                            "to" =>$row['to']
                                        ]);
                                    }else{
                                        $query=AvailabilityTime::create([
                                        'availability_id'=>$check->id,
                                            "from" =>$row['from'],
                                            "to" =>$row['to']
                                        ]);
                                    }
                                
                                }
                            }
                        }                    
                    }
                    if($query){  
                        return response()->json(["status" => 200,"success"=>true, "message" =>"Availability set success"]);
                    }else{ 
                        return response()->json(["status" => 400,"success"=>false, "message" =>"Availability could not be set "]);
                    }
                }else{
                    return response()->json(["status" => 400,"success"=>false, "message" =>"Failed try again"]);
                }                    
            }else{
                return response()->json(["status" => 400,"success"=>false, "message" =>"Failed try again"]);
            }
                
        }
        /* add availability end here */

        /* check availability */
        public function checkavailability($id=''){          
            
            if(!empty($id)){ 
                $checkLawyer=LawyerDetail::where('user_id',$id)->first();
                if(!empty($checkLawyer)){

                    $avilability=Availability::select('id','day_id','user_id','status')->where(['user_id'=>$id])->get();
                    if(sizeof($avilability)){                    
                        foreach($avilability as $row){
                            $chekctime=AvailabilityTime::select('from','to')->where('availability_id', $row->id)->where('status','1')->get();
                            if(count($chekctime)){
                                $data=[];
                                foreach($chekctime as $val){
                                    $data[]=$val;
                                }
                            }else{
                                $data=null;
                            }                        
                            $row->time=$data;
                            $data1[]= $row;
                        }
                        $array['is_call']=$checkLawyer->is_call;
                        $array['is_chat']=$checkLawyer->is_chat;
                        $array['call_charge']=$checkLawyer->call_charge;
                        $array['chat_charge']=$checkLawyer->chat_charge;
                        $array['availability']=$data1;
                        return response()->json(["status" => 200,"success"=>true,"message"=>"Availability list","data"=>$array]);
                    }else{
                        return response()->json(["status" => 400,"success"=>false,"message"=>"Data not found"]);                    
                    }
                }else{
                    return response()->json(["status" => 400,"success"=>false,"message"=>"User not found"]);
                }
                
              
            }else{  
                return response()->json(["status" => 400,"success"=>false,"message"=>"data not found"]);
            }                
        
        }
}
