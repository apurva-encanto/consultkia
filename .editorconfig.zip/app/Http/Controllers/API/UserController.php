<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Http\JsonResponse;
use App\Models\PasswordReset;
use Validator;
use Session;
use Auth;
use Storage;
use Carbon\Carbon;
use App\Models\User;
use App\Models\State;
use App\Models\Payment;
use App\Models\LawyerDetail;
use App\Models\PracticeArea;
use App\Models\Document;
use App\Models\Language;
use App\Models\Review;
use App\Models\Appointment;
use App\Models\Favorite;
use App\Models\Availability;
use App\Models\AvailabilityTime;
use App\Models\Splash;

use App\Notifications\SignupNotification;

class UserController extends ApiController

{

    public function __construct()
    {
        Auth::shouldUse('api');

    }
   

   
    public function register(Request $request){ 
        if($request->user_type==1){  
            $validator = Validator::make($request->all(), [
                'user_name' => 'required',
                'name' => 'required',
                'phone' => 'required',                 
                'fcm_token' => '',
                'city' => 'required',
                'refrence_code' => '',
                'gender' => 'required',
                'profile_img' => '',
                'user_type'=>"required",
            ]);
        }else{
            $validator = Validator::make($request->all(), [
                'user_type'=>"required",                    
                'phone' => 'required',                 
                'gender' => 'required',
                'profile_img' => '',
                'fcm_token' => '',
                'first_name' => 'required',
                'last_name' => 'required',
                'practice_area' => 'required',
                'practice_state' => 'required',
                'description' => 'required',
                'experience' => 'required',
                'education_details' => 'required',
                'language' => 'required',
                "license"=>'',
                "pan"=>'',
                'ac_no'=>'required',
                "ifsc"=>"required",
                "account_name"=>"required",

            ]);
        }
        // return $data;
        if($validator->fails()){
            return response()->json(["status" => 400, "success"=> false, "message" => $validator->messages()->first()]);
        }
        $randomString = Str::random(16);
        $checkusers=User::where('phone',$request->phone)->first();
        if(!empty($checkusers)){
            if($checkusers->is_verified=='1'){
                // if($checkusers->status=='0'){
                //     return response()->json(['status'=>400,'success'=>false,'message'=>"This is account has disable by admin"]);
                // }else{
                    return response()->json(['status'=>400,'success'=>false,'message'=>"Phone no. already has been taken !"]);
                // }               
            
            }else{
                $user=User::find($checkusers->id); 
                if($request->user_type==1){
                    $user->name = $request->name;
                    $user->user_name = $request->user_name;
                    $user->city = $request->city;
                }else{
                    $user->first_name = $request->first_name;
                    $user->last_name = $request->last_name;
                }
                $user->phone = $request->phone;
                $user->user_type = $request->user_type;
                $user->login_type = '1';
                $user->is_loggedin = '1';
                $user->user_type = '1';
                $user->referrel_code = $randomString;
                $user->fcm_token =$request->fcm_token?$request->fcm_token:null;                    
                $user->refrence_code = $request->refrence_code?$request->refrence_code:null;
                $user->gender = $request->gender?$request->gender:1;
                if($request->hasFile('profile_img')) {
                    $file = $request->file('profile_img');
                    $filename = time() . '_' . $file->extension();
                    $file->move(storage_path('app/public/profile'), $filename); 
                    $filename = trim(preg_replace('/\s+/','', $filename));
                    $user->profile_img=$filename;
                }     
                $query = $user->save();

                if($query==true){
                    if($request->user_type==2){
                        // return $checkusers->id;
                        $checkDetail=LawyerDetail::where('user_id',$checkusers->id)->first();
                        if(!empty($checkDetail)){
                            $saveDetail=LawyerDetail::find($checkDetail->id);
                        }else{
                            $saveDetail=new LawyerDetail();                                
                        }
                        $saveDetail->user_id=$user->id;
                        $saveDetail->practice_area=$request->practice_area;
                        $saveDetail->description=$request->description;
                        $saveDetail->practice_state=$request->practice_state;
                        $saveDetail->education_details=$request->education_details;
                        $saveDetail->experience=$request->experience;
                        $saveDetail->language=$request->language;
                        $saveDetail->description=$request->description?$request->description:null;
                        
                        $saveDetail->ac_no=$request->ac_no;
                        $saveDetail->ifsc=$request->ifsc;
                        $saveDetail->account_name=$request->account_name;
                        $detailQuery=$saveDetail->save();
                        if($detailQuery==true){                                
                            if($request->hasFile('license')) {                                    
                                    $check=Document::where('user_detail_id',$saveDetail->id)->where('doc_type','1')->first();
                                    if(!empty($check)){
                                        $delete=Document::where('user_detail_id',$saveDetail->id)->delete();
                                    }
                                    
                                    $filename = time() . '_' . $request->license->extension();
                                    $request->license->move(storage_path('app/public/user/'), $filename); 
                                    $filename = trim(preg_replace('/\s+/','', $filename));

                                    $document=new Document();                                    
                                    $document->user_detail_id=$saveDetail->id;
                                    $document->file=$filename;
                                    $document->doc_type="1";
                                    $documentquery=$document->save();
                                
                            }
                            if($request->hasFile('pan')) {                                    
                                $check=Document::where('user_detail_id',$saveDetail->id)->where('doc_type','2')->first();
                                if(!empty($check)){
                                    $delete=Document::where('user_detail_id',$saveDetail->id)->delete();
                                }
                                
                                $filename = time() . '_' . $request->pan->extension();
                                $request->pan->move(storage_path('app/public/user/'), $filename); 
                                $filename = trim(preg_replace('/\s+/','', $filename));

                                $document=new Document();                                    
                                $document->user_detail_id=$saveDetail->id;
                                $document->file=$filename;
                                $document->doc_type="2";
                                $documentquery=$document->save();
                            }  
                            
                        }
                    }
                    $token = $user->createToken($request->phone)->accessToken;
                    $userInfo['id'] = $user->id;
                    $userInfo['user_type'] = (int)$user->user_type;                        
                    $userInfo['phone'] = $user->phone;
                    $userInfo['referrel_code'] = $user->referrel_code;
                    $userInfo['gender'] = $user->gender;                        
                    $userInfo['fcm_token'] = $user->fcm_token;
                    $userInfo['token'] = $token;                    
                    $userInfo['is_verified'] =(int)$user->is_verified; 
                    $userInfo['profile_img'] = $user->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $user->profile_img)):user_img;                       
                    if($request->user_type==2){
                        $getLawyer=LawyerDetail::where('user_id',$user->id)->first();
                        if(!empty($getLawyer)){                            
                            $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $practice=[];
                            if(count($getarea)){                                            
                                foreach ($getarea as $value) {
                                    array_push($practice,$value->name);
                                }
                            }
                            $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $language=[];
                            if(count($getlanguage)){
                                foreach ($getlanguage as $value) {
                                    array_push($language,$value->language_name);
                                }
                            }
                            $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $state=[];
                            if(count($getstate)){                                            
                                foreach ($getstate as $value) {
                                    array_push($state,$value->state_name);
                                }
                            }
                            $language=implode(',',$language);
                        }
                        $userInfo['first_name'] = $user->first_name;
                        $userInfo['last_name'] = $user->last_name;
                        $userInfo['practice_area']=$practice;
                        $userInfo['practice_state']=$state;
                        $userInfo['description']=$request->description;
                        $userInfo['education_details']=$request->education_details;
                        $userInfo['experience']=$request->experience;
                        $userInfo['education_details']=$request->education_details;
                        $userInfo['language']=$language;
                        $userInfo['description']=$request->description?$request->description:null;
                        $userInfo['ac_no']=$request->ac_no;
                        $userInfo['ifsc']=$request->ifsc;
                        $userInfo['account_name']=$request->account_name;
                        $license=Document::select('id','file','doc_type')->where('user_detail_id',$saveDetail->id)->where('doc_type','1')->first();
                        $pan=Document::select('id','file','doc_type')->where('user_detail_id',$saveDetail->id)->where('doc_type','2')->first();
                        
                        
                        $userInfo['license']=$license->file?imgUrl.'user/'.$license->file:null;                                   
                        $userInfo['pan']=$pan->file?imgUrl.'user/'.$pan->file:null;
                    }else{
                        $userInfo['name'] = $user->name;
                        $userInfo['user_name'] = $user->user_name;
                        $userInfo['city'] = $user->city;
                        $userInfo['refrence_code'] = $user->refrence_code;
                    } 
                    return response()->json(["status"=>200, "success" =>true, "message" => "User Registered Successfully ", "data" => $userInfo]);        
                
                }else{
                    return response()->json(["status" => 400, "success" =>false, "message" => "Registration Failed try Again"]);
                }
            }            
        }else{
                $user=new User(); 
                if($request->user_type==1){
                    $user->name = $request->name;
                    $user->user_name = $request->user_name;
                    $user->city = $request->city;
                }else{
                    $user->first_name = $request->first_name;
                    $user->last_name = $request->last_name;
                }
                

               
                $user->referrel_code = $randomString;
                $user->phone = $request->phone;
                $user->user_type = $request->user_type;
                $user->login_type = '1';
                $user->is_loggedin = '1';
                $user->user_type = 1;
                $user->fcm_token =$request->fcm_token?$request->fcm_token:null;
                $user->refrence_code = $request->refrence_code?$request->refrence_code:null;
                $user->gender = $request->gender?$request->gender:1;
                if($request->hasFile('profile_img')) {
                    $file = $request->file('profile_img');
                    $filename = time() . '_' . $file->extension();
                    $file->move(storage_path('app/public/profile'), $filename); 
                    $user->profile_img=$filename;
                }     
                $query = $user->save();

                if($query==true){
                    if($request->user_type==2){
                        $checkDetail=LawyerDetail::where('user_id',$user->id)->first();
                        if(!empty($checkDetail)){
                            $saveDetail=LawyerDetail::find($checkDetail->id);
                        }else{
                            $saveDetail=new LawyerDetail();                                
                        }
                        $saveDetail->user_id=$user->id;
                        $saveDetail->practice_area=$request->practice_area;
                        $saveDetail->practice_state=$request->practice_state;
                        $saveDetail->description=$request->description;
                        $saveDetail->education_details=$request->education_details;
                        $saveDetail->experience=$request->experience;
                        $saveDetail->language=$request->language;                            
                        $saveDetail->ac_no=$request->ac_no;
                        $saveDetail->ifsc=$request->ifsc;
                        $saveDetail->account_name=$request->account_name;
                        $detailQuery=$saveDetail->save();
                        if($detailQuery==true){                                
                            if($request->hasFile('docs_img')) {
                                foreach($request->file('docs_img`')as $file){                                    
                                    $filename = time() . '_' . $file->extension();
                                    $file->move(storage_path('app/public/user/'), $filename); 
                                    $filename = trim(preg_replace('/\s+/','', $filename));
                                    $document[]=$filename;
                                }
                                $check=Document::where('user_detail_id',$saveDetail->id)->first();
                                if(!empty($check)){
                                    $delete=Document::where('user_detail_id',$saveDetail->id)->delete();
                                }
                                foreach($document as $file){
                                    $document=new Documnet();                                    
                                    $document->file=$file;
                                    $documentquery=$document->save();
                                }
                            }   
                            
                        }
                    }
                    $token = $user->createToken($request->phone)->accessToken;
                    $userInfo['id'] = $user->id;
                    $userInfo['user_type'] = (int)$user->user_type;                        
                    $userInfo['phone'] = $user->phone;
                    $userInfo['referrel_code'] = $user->referrel_code;
                    
                    $userInfo['gender'] = $user->gender;
                    $userInfo['fcm_token'] = $user->fcm_token;
                    $userInfo['token'] = $token;                    
                    $userInfo['is_verified'] =(int)$user->is_verified; 
                    $userInfo['profile_img'] = $user->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $user->profile_img)):user_img;                       
                    if($request->user_type==2){
                        $getLawyer=LawyerDetail::where('user_id',$user->id)->first();
                        if(!empty($getLawyer)){                            
                            $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $practice=[];
                            if(count($getarea)){                                            
                                foreach ($getarea as $value) {
                                    array_push($practice,$value->name);
                                }
                            }
                            $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $language=[];
                            if(count($getlanguage)){
                                foreach ($getlanguage as $value) {
                                    array_push($language,$value->language_name);
                                }
                            }
                            $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                            $state=[];
                            if(count($getstate)){                                            
                                foreach ($getstate as $value) {
                                    array_push($state,$value->state_name);
                                }
                            }
                            $language=implode(',',$language);
                        }
                        $userInfo['first_name'] = $user->first_name;
                        $userInfo['last_name'] = $user->last_name;
                        $userInfo['practice_area']=$practice;
                        $userInfo['practice_state']=$state;
                        $userInfo['description']=$request->description;
                        $userInfo['education_details']=$request->education_details;
                        $userInfo['experience']=$request->experience;
                        $userInfo['language']=$language;
                        $userInfo['ac_no']=$request->ac_no;
                        $userInfo['ifsc']=$request->ifsc;
                        $userInfo['account_name']=$request->account_name;

                        
                    }else{
                        $userInfo['name'] = $user->name;
                        $userInfo['user_name'] = $user->user_name;
                        $userInfo['city'] = $user->city;
                        $userInfo['refrence_code'] = $user->refrence_code;
                    }
                                         
                    if($request->user_type==2){
                        $data['lawyer']=$userInfo;
                    }else{
                        $data['user']=$userInfo;
                    }
                    return response()->json(["status"=>200, "success" =>true, "message" => "User Registered Successfully ", "data" => $data]);        
                
                }else{
                    return response()->json(["status" => 400, "success" =>false, "message" => "Registration Failed try Again"]);
                }
        }
    
    }

    // user login

    public function login(Request $request){       
        $validator = Validator::make($request->all(),[
            'phone' => 'required',                
            'fcm_token' => '',
            'user_type'=>"required"
        ]);
        if($validator->fails()){
            return response()->json(["status" => 400, "success"=> false, "message" => $validator->messages()->first()]);
        }
        //check email format
        $is_phone = $request->input('phone');
        
        if(!empty($is_phone)){
            $user=User::where('phone',$is_phone)->first();
            if(!empty($user)){    
                if($user->is_verified==1){ 
                    if($user->user_type == $request->user_type){                        
                        $statusCheck = User::where([['phone', $is_phone],['user_type',$request->user_type],['status','1']])->first();
                        if(!empty($statusCheck)){  

                            $update=User::where('id', $user->id)->update(['fcm_token'=>$request->fcm_token?$request->fcm_token:null, 'is_loggedin'=>'1']);
                            $token = $user->createToken($request->phone)->accessToken;
                            $userInfo['id'] = $user->id;
                            $userInfo['user_type'] = (int)$user->user_type;                        
                            $userInfo['phone'] = $user->phone;
                            $userInfo['referrel_code'] = $user->referrel_code;
                            $userInfo['gender'] = $user->gender;
                            $userInfo['fcm_token'] = $user->fcm_token;
                            $userInfo['token'] = $token;                    
                            $userInfo['is_verified'] =(int)$user->is_verified; 
                            $userInfo['profile_img'] = $user->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $user->profile_img)):user_img;                       
                            if($request->user_type==2){
                                $getLawyer=LawyerDetail::where('user_id',$user->id)->first();
                                $userInfo['first_name'] = $user->first_name;
                                $userInfo['last_name'] = $user->last_name;
                                if(!empty($getLawyer)){
                                    $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                                    $practice=[];
                                    if(count($getarea)){                                            
                                        foreach ($getarea as $value) {
                                            array_push($practice,$value->name);
                                        }
                                    }
                                    $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                                    $language=[];
                                    if(count($getlanguage)){
                                        foreach ($getlanguage as $value) {
                                            array_push($language,$value->language_name);
                                        }
                                    }
                                    $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                                    $state=[];
                                    if(count($getstate)){                                            
                                        foreach ($getstate as $value) {
                                            array_push($state,$value->state_name);
                                        }
                                    }
                                    $language=implode(',',$language);
                                    
                                    $userInfo['education_details']=$request->education_details;
                                    $userInfo['experience']=$request->experience;
                                    $userInfo['description']=$request->description;
                                    $userInfo['ac_no']=$request->ac_no;
                                    $userInfo['ifsc']=$request->ifsc;
                                    $userInfo['account_name']=$request->account_name;
                                    $userInfo['language']=$language;
                                    $userInfo['practice_area']=$practice;
                                    $userInfo['practice_state']=$state;
                                }
                                
                                

                               
                            }else{
                                $userInfo['name'] = $user->name;
                                $userInfo['user_name'] = $user->user_name;
                                $userInfo['city'] = $user->city;
                                $userInfo['refrence_code'] = $user->refrence_code;
                            }
                            if($request->user_type==2){
                                $data['lawyer']=$userInfo;
                            }else{
                                $data['user']=$userInfo;
                            }
                
                
                
                            return response()->json(['status' => 200, 'success'=>true, 'message' =>"You've Successfully logged In", 'data' => $userInfo]);                                
                            
                        }else{
                            return response()->json(['status'=>400,'success'=>false, 'massage' =>"Account is disable from admin"]);
                        }                        
                    }else{                        
                        return response()->json(['status'=>400, 'success'=>false,'massage' =>"Couldn't find your account"]);
                    }
                }else{
                    return response()->json(['status'=>400, 'success'=>false,'massage' =>"Couldn't find your account"]);
                }
            }else{
                return response()->json(["status" => 400, "success" => false, 'message' =>"User not exist"]);
            }                
        }else{
            return response()->json(["status" => 400, "success" => false, 'message' =>"User not exist"]);
        }           
    
    }

    public function checkUser(Request $request){       
        $validator = Validator::make($request->all(),[
            'phone' => 'required',           
            
        ]);
        if($validator->fails()){
            return response()->json(["status" => 400, "success"=> false, "message" => $validator->messages()->first()]);
        }            
        
        $user=User::where(['phone'=>$request->phone,'is_verified'=>'1'])->first();
        if(!empty($user)){                
            return response()->json(['status'=>400, 'success'=>false,'massage' =>"Phone no. already taken"]);
            
        }else{
            return response()->json(["status" => 200, "success" => True, 'message' =>"Available"]);
        }                
                  
    
    }

    public function changePassword(Request $request){
        $data = json_decode($request->getContent(), true);
        $validator = Validator::make($data, [

            'old_password' => 'required',
            'new_password' => 'required|min:8|max:32',
            'confirm_password' => 'required|min:8|max:32',
        ]);
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first(),'status' => 200,'success'=>false]);

          
        }
        $hashedPassword = Auth::user()->password;
        if(\Hash::check($request->old_password,$hashedPassword)){
            if(!\Hash::check($request->new_password , $hashedPassword)) {
                  $users =User::find(Auth::user()->id);
                  $users->password = bcrypt($request->new_password);
                  User::where('id' , Auth::user()->id)->update(["temporary_password"=>$request->new_password,'password' => $users->password]);
                return response()->json(['status' => 200,'success'=>true,'message' =>'password changed successfully']);
            }else{
                return response()->json(['status'=>400,'success' => false,'message' => 'new password can not be same from previous password!']);
                }
        }else{
            return response()->json(['status' => 400,'success'=>false,'message' =>"The old password doesn't match."]);                  
        }

    }

    public function logout(){ 
        $user = Auth::user()->token(); 
        $user_id = Auth::user()->id;
        $update['fcm_token'] = '';
        $update['is_loggedin'] = '0';
        $query = User::where('id',$user_id)->update($update);
        $user->revoke();
        return response()->json(['status' => 200,'success' => true, 'message' =>"Successfully Logged out"]);

    }


    public function updateProfile(Request $request){
        $user=Auth::user();  
        if($request->user_type==1){  
            $validator = Validator::make($request->all(), [
                'user_name' => 'required',
                'name' => 'required',
                'city' => 'required',                    
                'gender' => 'required',
                'profile_img' => '',
                'user_type'=>"required",
            ]);
        }else{
            $validator = Validator::make($request->all(), [
                'user_type'=>"required",
                'gender' => 'required',
                'profile_img' => '',
                'first_name' => 'required',
                'last_name' => 'required',
                'practice_area' => 'required',
                'practice_state' => 'required',
                'description' => 'required',
                'experience' => 'required',
                'language' => 'required',
                "license"=>'',
                "pan"=>'',
                'ac_no'=>'required',
                "ifsc"=>"required",
                "account_name"=>"required",

            ]);
        }
                 
        if($validator->fails()){
            return response()->json(['status'=>400,'success' => false, 'message' => $validator->errors()->first()]);
        }
                  
        if(!empty($user)){
            if($request->user_type==2){
                $user->user_name=$request->user_name;
                $user->name=$request->name;
                $user->gender=$request->gender;
                if($request->hasFile('profile_img')) {
                    $file = $request->file('profile_img');
                    $filename = time() . '_' . $file->extension();
                    $file->move(storage_path('app/public/profile'), $filename); 
                    $user->profile_img=$filename;
                }    
                $query=$user->save();
                $checkDetail=LawyerDetail::where('user_id',$user->id)->first();
                if(!empty($checkDetail)){
                    $saveDetail=LawyerDetail::find($checkDetail->id);
                }else{
                    $saveDetail=new LawyerDetail();                                
                }
                $saveDetail->user_id=$user->id;
                $saveDetail->practice_area=$request->practice_area;
                $saveDetail->practice_state=$request->practice_state;
                $saveDetail->description=$request->description;
                $saveDetail->education_details=$request->education_details;
                $saveDetail->experience=$request->experience;
                $saveDetail->language=$request->language;
                $saveDetail->description=$request->description?$request->description:null;
                
                $saveDetail->ac_no=$request->ac_no;
                $saveDetail->ifsc=$request->ifsc;
                $saveDetail->account_name=$request->account_name;
                $detailQuery=$saveDetail->save();
                if($detailQuery==true){                                
                    if($request->hasFile('license')) {                                    
                            $check=Document::where('user_detail_id',$saveDetail->id)->where('doc_type','1')->first();
                            if(!empty($check)){
                                $delete=Document::where('user_detail_id',$saveDetail->id)->delete();
                            }
                            
                            $filename = 'license' . time() . '.' . $request->license->extension();
                            $request->license->move(storage_path('app/public/user/'), $filename); 
                            $filename = trim(preg_replace('/\s+/','', $filename));

                            $document=new Document();                                    
                            $document->user_detail_id=$saveDetail->id;
                            $document->file=$filename;
                            $document->doc_type="1";
                            $documentquery=$document->save();
                        
                    }
                    if($request->hasFile('pan')) {                                    
                        $check=Document::where('user_detail_id',$saveDetail->id)->where('doc_type','2')->first();
                        if(!empty($check)){
                            $delete=Document::where('user_detail_id',$saveDetail->id)->delete();
                        }
                        
                        $filename ='pan' . time() . '.' . $request->pan->extension();
                        $request->pan->move(storage_path('app/public/user/'), $filename); 
                        $filename = trim(preg_replace('/\s+/','', $filename));

                        $document=new Document();                                    
                        $document->user_detail_id=$saveDetail->id;
                        $document->file=$filename;
                        $document->doc_type="2";
                        $documentquery=$document->save();
                    }  
                   return response()->json(["status" => 200,"success" => true, "message" => "Profile successfully update"]);    
                }
            }else{                    
                $user->user_name=$request->user_name;
                $user->name=$request->name;                   
                $user->city=$request->city;
                $user->gender=$request->gender;
                 if($request->hasFile('profile_img')) {
                    $file = $request->file('profile_img');
                    $filename = time() . '_' . $file->extension();
                    $file->move(storage_path('app/public/profile'), $filename); 
                    $user->profile_img=$filename;
                }    
                $query=$user->save();
                if($query==true){
                   return response()->json(["status" => 200,"success" => true, "message" => "Profile successfully update"]);  
                }else{
                    return response()->json(["status" =>400,"success" => false, "message" => "Profile not update"]); 
                }                
            } 
        
        }else{
            return response()->json(["status" => 400, 'success'=>false, "message" =>"User doesn't exist"]);
        }

    }

    public function getLawyerDeatils($id=''){  
        if($id!=''){
            $getLawyer=LawyerDetail::where('lawyer_details.user_id',$id)
                ->join('users','users.id','lawyer_details.user_id')
                ->where('users.is_verified','1')->where('users.user_type','2')->first();   
                   
            if(!empty($getLawyer)){ 
                // json_decode(json)
                $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $practice=[];
                if(count($getarea)){
                    // $practice=[];
                    foreach ($getarea as $value) {
                        array_push($practice,$value->name);
                    }
                }
                $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $language=[];
                if(count($getlanguage)){
                    // $practice=[];
                    foreach ($getlanguage as $value) {
                        array_push($language,$value->language_name);
                    }
                }
                $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $state=[];
                if(count($getstate)){
                    // $practice=[];
                    foreach ($getstate as $value) {
                        array_push($state,$value->state_name);
                    }
                }
                // return $practice;
                $language=implode(',',$language);
                $userInfo['is_active']=0;
                $user=Auth::user();
                if(!empty($user)){                
                    $fav=Favorite::where('status','1')->where('lawyer_id',$id)->where('user_id',$user->id)->first();
                   
                    if(!empty($fav)){
                        $userInfo['is_favorite']=1;
                    }else{
                        $userInfo['is_favorite']=0;
                    }
                    $utcTime = Carbon::now()->format('Y-m-d H:i:s');

                    $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
                    $today = Carbon::now();
                    $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
                    
                    $dayOfWeek = $today->dayOfWeek;
                    $checklawyer=Availability::where(['user_id'=>$id,'day_id'=>$dayOfWeek,'status'=>'1'])->first();
                    if(!empty($checklawyer)){
                       
                        $gettime=AvailabilityTime::where('availability_id',$checklawyer->id)->where('status','1')->get();
                        if(sizeof($gettime)){
                            foreach ($gettime as $value) {
                                $fromtimearray=explode(":", $value->from);
                                $totimearray=explode(":", $value->to);

                                $mytimeArray = explode(":", $todaytime);
                                
                                $toTime = Carbon::createFromTime($totimearray[0], $totimearray[1], $totimearray[2]);
                                $fromTime = Carbon::createFromTime($fromtimearray[0], $fromtimearray[1], $fromtimearray[2]);

                                $myTime = Carbon::createFromTime($mytimeArray[0], $mytimeArray[1], $mytimeArray[2]);
                                
                                if ($myTime->between($fromTime, $toTime)){
                                    $dataactive=1;
                                }else{
                                    $dataactive=0;
                                } 
                            }
                            $userInfo['is_active']=$dataactive;
                        }
                        
                    }
                    
                }else{
                     $userInfo['is_favorite']=0;
                }
                $rating=Review::where('lawyer_id',$id)->avg('rating');
                $getreview=Review::where('lawyer_id',$id)->count('id');
                $userInfo['id'] = $id;
                $userInfo['user_type'] = (int)$getLawyer->user_type;                        
                $userInfo['phone'] = $getLawyer->phone;                    
                $userInfo['gender'] = $getLawyer->gender;                                                     
                $userInfo['is_verified'] =(int)$getLawyer->is_verified; 
                $userInfo['profile_img'] = $getLawyer->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $getLawyer->profile_img)):user_img;
                $userInfo['first_name'] = $getLawyer->first_name;
                $userInfo['last_name'] = $getLawyer->last_name;
                $userInfo['practice_area']=$practice;
                $userInfo['practice_state']=$state;
                $userInfo['description']=$getLawyer->description;
                $userInfo['education_details']=$getLawyer->education_details;
                $userInfo['experience']=$getLawyer->experience;
                $userInfo['language']=$language;
                $userInfo['ac_no']=$getLawyer->ac_no;
                $userInfo['ifsc']=$getLawyer->ifsc;
                $userInfo['account_name']=$getLawyer->account_name;
                $userInfo['rating']=round($rating,2);
                $userInfo['total_review']=$getreview;
                $userInfo['is_active']=0;
                   
                // $userInfo['docs']=$docs;
                
                
                return response()->json(['status' => 200,"success" => true,'message'=> "Lawyer Details",'data'=>$userInfo]);
            }else{
                return response()->json(['status' => 400,"success" => false,'message'=> "User not exist"]);
            }
        }else{
            return response()->json(['status' => 400,"success" => false,'message'=> "User not found"]);
        }
        
    }


    public function getprofile(){  
        $users=Auth::user();
        if(!empty($users)){
            
            $user=User::where('id',$users->id)->where('is_verified','1')->first();
            if(!empty($user)){ 
                $userInfo['id'] = $user->id;
                $userInfo['user_type'] = (int)$user->user_type;                        
                $userInfo['phone'] = $user->phone;
                // $userInfo['referrel_code'] = $user->referrel_code;
                $userInfo['gender'] = $user->gender;
                $userInfo['fcm_token'] = $user->fcm_token;                                   
                // $userInfo['is_verified'] =(int)$user->is_verified; 
                $userInfo['profile_img'] = $user->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $user->profile_img)):user_img;                       
                if($user->user_type==2){
                    $getLawyer=LawyerDetail::where('user_id',$user->id)->first();

                    $userInfo['first_name'] = $user->first_name;
                    $userInfo['last_name'] = $user->last_name;
                    if(!empty($getLawyer)){
                        $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                        $practice=[];
                        if(count($getarea)){
                            // $practice=[];
                            foreach ($getarea as $value) {
                                array_push($practice,$value->name);
                            }
                        }
                        $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                        $language=[];
                        if(count($getlanguage)){
                            // $practice=[];
                            foreach ($getlanguage as $value) {
                                array_push($language,$value->language_name);
                            }
                        }
                        $language=implode(',',$language);
                        $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                        $state=[];
                        if(count($getstate)){
                            // $practice=[];
                            foreach ($getstate as $value) {
                                array_push($state,$value->state_name);
                            }
                        }
                        
                        $userInfo['education_details']=$getLawyer->education_details;
                        $userInfo['experience']=$getLawyer->experience;
                        $userInfo['ac_no']=$getLawyer->ac_no;
                        $userInfo['ifsc']=$getLawyer->ifsc;
                        $userInfo['account_name']=$c->account_name;
                        $userInfo['language']=$language;
                        $userInfo['practice_area']=$practice;
                        $userInfo['practice_state']=$state;
                        $userInfo['description']=$description->description;
                    }

                    $license=Document::select('file')->where('user_detail_id',$getLawyer->id)->where('doc_type','1')->first();
                    if(!empty($license)){
                        $userInfo['license']=$license->file?imgUrl.'user/'.$license->file:null; 
                    }else{
                        $userInfo['license']=null;
                    }
                    $pan=Document::select('file')->where('user_detail_id',$getLawyer->id)->where('doc_type','2')->first();
                    if(!empty($pan)){
                        $userInfo['pan']=$pan->file?imgUrl.'user/'.$pan->file:null;
                    }else{
                        $userInfo['pan']=null;
                    }                                       
                            
                }else{
                    $userInfo['name'] = $user->name;
                    $userInfo['user_name'] = $user->user_name;
                    $userInfo['city'] = $user->city;
                    $userInfo['refrence_code'] = $user->refrence_code;
                }
                if($user->user_type==2){
                    return response()->json(['status' => 200,"success" => true,'message'=> "Profile Details",'data'=>$userInfo]);
                    
                }else{
                    return response()->json(['status' => 200,"success" => true,'message'=> "Profile Details",'data'=>$userInfo]);
                   
                }
                
            }else{
                return response()->json(['status' => 400,"success" => false,'message'=> "User not exist"]);
            }
        }else{
            return response()->json(['status' => 401,"success" => false,'message'=> "You're not logged in"]);
        }
        
    }

    public function removeProfileImge(Request $request){
        $rvn=Auth::user();            
         $path=storage_path("app/public/user_profile/".$rvn->profile_img);
            unlink($path);                
            $query=User::where(['id'=>$rvn->id,'status'=>'1'])->update([
                'profile_img'=>''
            ]); 
        if($query){                        
            return response()->json(["status"=>200,"success"=>true,"message" =>"Profile Image successfully remove"]);
        }else{    
        return response()->json(["status" => 400,"success"=>false,"message"=>"Profile remove failed try again"]);

        } 
         
    }
    
    public function favoriteUnfavorite(Request $request){
        $validator=Validator::make($request->all(),[
            "lawyer_id"=>"required",
            
        ]);
        if($validator->fails()){
            return response()->json(["status" => 400, "success"=> false, "message" => $validator->messages()->first()]);
        }
        $user=Auth::user();
        if(!empty($user)){
            if($user->user_type==1){
                $check=Favorite::where('user_id',$user->id)->where('lawyer_id',$request->lawyer_id)->first();
                if(!empty($check)){
                    $favorite=Favorite::find($check->id);
                    if($favorite->status==1){
                        $favorite->status=0;
                    }else{
                        $favorite->status=1;
                    }
                }else{
                    $favorite=new Favorite();
                    $favorite->status=1;
                }
                $favorite->user_id=$user->id;
                $favorite->lawyer_id=$request->lawyer_id;
                
                $query=$favorite->save();
                if($query==true){
                    if($favorite->status==1){
                        $msg="lawyer added as favorite";
                    }else{
                        $msg="lawyer remove from favorite list";
                    }
                    return response()->json(["status" => 200,"success"=>true,"message"=>$msg]);
                }else{
                    return response()->json(["status" => 400,"success"=>false,"message"=>"Something went wrong try again"]); 
                }
            }else{
                return response()->json(["status" => 400,"success"=>false,"message"=>"You're not auhtorized"]);
            }
        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You've to login first"]); 
        }
    }


    public function favoriteUnfavoriteList(){
       
        $user=Auth::user();       
        if(!empty($user)){
            if($user->user_type==1){
               $favorite= DB::table('lawyer_details')
                ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
                ->join('users', 'users.id', '=', 'lawyer_details.user_id')
                ->join('favorites', 'favorites.lawyer_id', '=', 'lawyer_details.user_id')
                ->where('users.is_verified', 1)
                ->where('users.is_verified', 1)
                ->where('favorites.user_id',$user->id)
                ->where('favorites.status','1')
                // ->orderByDesc('ratings.average_rating')
                ->get();                
                if(sizeof($favorite)){
                    foreach($favorite as $row){
                        $lawyerDetails=User::select('first_name','last_name','profile_img','city')->where('id',$row->user_id)->first();
                        
                        if(!empty($lawyerDetails)){
                            $practice_area=json_decode($row->practice_area);                            
                            foreach($practice_area as $area){
                                $getarea=PracticeArea::select('name')->where('id',$area)->first();                               
                                if(!empty($getarea)){
                                    $area=$getarea->name;
                                    $areadata[]=$area;
                                }
                            }
                            $languages=json_decode($row->language);  
                            $language_name=[];
                            foreach($languages as $language){
                                $getlanguage=Language::select('language_name')->where('id',$language)->first();
                                if(!empty($getlanguage)){
                                    $language=$getlanguage->language_name;
                                    $language_name[]=$language;
                                }
                            }
                        
                            $user_name=$lawyerDetails->first_name.' '.$lawyerDetails->last_name;
                            $city=$lawyerDetails->city;
                            $language=implode(',',$language_name);
                            $language=$language;
                            $area=$areadata;
                            $profile_img=$lawyerDetails->profile_img?imgUrl.'profile/'.$lawyerDetails->profile_img:user_img;
                        }
                        $rating=Review::where('lawyer_id',$row->user_id)->avg('rating');
                        $getreview=Review::where('lawyer_id',$row->user_id)->count('id');
                        $row->id=$row->user_id;
                        $row->user_name=$user_name;
                        $row->profile_img=$profile_img;
                        $row->education_details=$row->education_details;
                        $row->experience=$row->experience;
                        $row->language=$language;
                        // $row->practice_area=$area;
                        $row->practice_area=implode(',', $area);
                        $row->rating=round($rating,2);
                        $row->reviews=$getreview;
                        $data[]=$row;
                        unset($row->user_id);
                        unset($row->average_rating);
                    }
                    
                    return response()->json(["status" => 200,"success"=>true,"message"=>"All Favorite lawyer list",'data'=>$data]); 
        
                }else{
                    return response()->json(["status" => 200,"success"=>true,"message"=>"favoritet",'data'=>array()]); 
                }
            }else{
                return response()->json(["status" => 400,"success"=>false,"message"=>"You're not auhtorized"]);
            }
        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You've to login first"]); 
        }
    }

    public function lawyersList($type=''){  
        if($type==1){
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            
        
            ->where('users.is_verified', 1)
            // ->orderByDesc('ratings.average_rating')
            ->get();
            $msg="Premium Lawyer list";
        
        }elseif($type==2){

            
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            
        
            ->where('users.is_verified', 1)
            // ->orderByDesc('ratings.average_rating')
            ->get();
         $msg="Active Lawyer list";
        
        }elseif($type==3){
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            
        
            ->where('users.is_verified', 1)
            // ->orderByDesc('ratings.average_rating')
            ->get();
    
         $msg="Family Lawyer list";
        }else{
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            
        
            ->where('users.is_verified', 1)
            // ->orderByDesc('ratings.average_rating')
            ->get();
             $msg="All Lawyer list";
        }

        if(sizeof($lawyers)){
            $data=[];
            foreach($lawyers as $row){
                $lawyerDetails=User::select('first_name','last_name','profile_img','city')->where('id',$row->user_id)->first();
                
                if(!empty($lawyerDetails)){
                    $practice_area=json_decode($row->practice_area);
                    $areadata=[]; 
                    foreach($practice_area as $area){
                        $getarea=PracticeArea::select('name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->name;
                            $areadata[]=$area;
                        }
                    }
                    $practice_state=json_decode($row->practice_state);
                    $state=[]; 
                    foreach($practice_state as $area){
                        $getarea=State::select('state_name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->state_name;
                            $state[]=$area;
                        }
                    }
                    $languages=json_decode($row->language); 
                    $language_name=[]; 
                    foreach($languages as $language){
                        $getlanguage=Language::select('language_name')->where('id',$language)->first();
                        if(!empty($getlanguage)){
                            $language=$getlanguage->language_name;
                            $language_name[]=$language;
                        }
                        
                    }
                
                    $user_name=$lawyerDetails->first_name.' '.$lawyerDetails->last_name;
                    $city=$lawyerDetails->city;
                    $language1=implode(',',$language_name);
                    $language=$language1;
                    $area=$areadata;
                    $profile_img=$lawyerDetails->profile_img?imgUrl.'profile/'.$lawyerDetails->profile_img:user_img;
                }
                $user=Auth::user();
                if(!empty($user)){
                    $fav=Favorite::where('status','1')->where('lawyer_id',$row->user_id)->where('user_id',$user->id)->first();                   
                    if(!empty($fav)){
                        $row->is_favorite=1;
                    }else{
                        $row->is_favorite=0;
                    }
                    $utcTime = Carbon::now()->format('Y-m-d H:i:s');

                    $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
                    $today = Carbon::now();
                    $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
                    
                    $dayOfWeek = $today->dayOfWeek;
                    $checklawyer=Availability::where(['user_id'=>$row->user_id,'day_id'=>$dayOfWeek,'status'=>'1'])->first();
                    if(!empty($checklawyer)){

                        $gettime=AvailabilityTime::where('availability_id',$checklawyer->id)->where('status','1')->get();
                        if(sizeof($gettime)){
                            foreach ($gettime as $value) {
                                $fromtimearray=explode(":", $value->from);
                                $totimearray=explode(":", $value->to);

                                $mytimeArray = explode(":", $todaytime);
                                // return $mytimeArray;
                                $toTime = Carbon::createFromTime($totimearray[0], $totimearray[1], $totimearray[2]);
                                $fromTime = Carbon::createFromTime($fromtimearray[0], $fromtimearray[1], $fromtimearray[2]);

                                $myTime = Carbon::createFromTime($mytimeArray[0], $mytimeArray[1], $mytimeArray[2]);
                                // echo  $toTime.'-----'.$fromTime.'----'.$myTime;// return $myTime;
                                
                                if ($myTime->between($fromTime, $toTime)){
                                    $dataactive=1;
                                }else{
                                    $dataactive=0;
                                } 
                            }
                            $row->is_active=$dataactive;
                        }
                        
                    }
                   

                }else{
                        $row->is_favorite=0;
                        $row->is_active=0;
                        
                }

                $getreview=Review::where('lawyer_id',$row->user_id)->count('id');
                $rating=Review::where('lawyer_id',$row->user_id)->avg('rating');
                // $row->is_active=0;
                $row->id=$row->user_id;
                $row->user_name=$user_name;
                $row->profile_img=$profile_img;
                $row->is_call=$row->is_call;
                $row->is_chat=$row->is_chat;
                $row->call_charge=$row->call_charge;
                $row->chat_charge=$row->chat_charge;
                $row->experience=$row->experience;
                $row->education_details=$row->education_details?$row->education_details:null;
                $row->language=$language;
                // $row->practice_area=$area;
                $row->practice_area=implode(',', $area);
                $row->practice_state=$state;
                $row->rating=round($rating,2);
                $row->total_review=$getreview;
                
                $data[]=$row;
                unset($row->user_id);                
                // unset($row->average_rating);
            }
            // return $data;
            return response()->json(["status" => 200,"success"=>true,"message"=>$msg,'data'=>$data]); 

        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You've to login first"]); 
        }
    }

    public function lawyerByArea($type=''){  
        // $type=(array)$type;
        $lawyers = DB::table('lawyer_details')
        ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.education_details','lawyer_details.language')
        ->join('users', 'users.id', '=', 'lawyer_details.user_id')
        ->where('users.is_verified', 1)
        ->where('lawyer_details.practice_area', 'LIKE', '%' . $type . '%')
       
        ->get();
        // return $lawyers;

        if(sizeof($lawyers)){
            $data=[];
            foreach($lawyers as $row){
                $lawyerDetails=User::select('first_name','last_name','profile_img','city')->where('id',$row->user_id)->first();                
                if(!empty($lawyerDetails)){
                    $practice_area=json_decode($row->practice_area);
                    $areadata=[]; 
                    foreach($practice_area as $area){
                        $getarea=PracticeArea::select('name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->name;
                            $areadata[]=$area;
                        }
                    }
                    $practice_state=json_decode($row->practice_state);
                    $state=[]; 
                    foreach($practice_state as $area){
                        $getarea=State::select('state_name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->state_name;
                            $state[]=$area;
                        }
                    }
                    $languages=json_decode($row->language); 
                    $language_name=[]; 
                    foreach($languages as $language){
                        $getlanguage=Language::select('language_name')->where('id',$language)->first();
                        if(!empty($getlanguage)){
                            $language=$getlanguage->language_name;
                            $language_name[]=$language;
                        }
                        
                    }
                
                    $user_name=$lawyerDetails->first_name.' '.$lawyerDetails->last_name;
                    $city=$lawyerDetails->city;
                    $language1=implode(',',$language_name);
                    $language=$language1;
                    $area=$areadata;
                    $profile_img=$lawyerDetails->profile_img?imgUrl.'profile/'.$lawyerDetails->profile_img:user_img;
                }
                $user=Auth::user();
                if(!empty($user)){
                    $fav=Favorite::where('status','1')->where('lawyer_id',$row->user_id)->where('user_id',$user->id)->first();                   
                    if(!empty($fav)){
                        $row->is_favorite=1;
                    }else{
                        $row->is_favorite=0;
                    }
                    $utcTime = Carbon::now()->format('Y-m-d H:i:s');

                    $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
                    $today = Carbon::now();
                    $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
                    
                    $dayOfWeek = $today->dayOfWeek;
                    $checklawyer=Availability::where(['user_id'=>$row->user_id,'day_id'=>$dayOfWeek,'status'=>'1'])->first();
                    if(!empty($checklawyer)){
                        $gettime=AvailabilityTime::where('availability_id',$checklawyer->id)->where('status','1')->get();
                        if(sizeof($gettime)){
                            foreach ($gettime as $value) {
                                $fromtimearray=explode(":", $value->from);
                                $totimearray=explode(":", $value->to);
                                $mytimeArray = explode(":", $todaytime);                                
                                $toTime = Carbon::createFromTime($totimearray[0], $totimearray[1], $totimearray[2]);
                                $fromTime = Carbon::createFromTime($fromtimearray[0], $fromtimearray[1], $fromtimearray[2]);
                                $myTime = Carbon::createFromTime($mytimeArray[0], $mytimeArray[1], $mytimeArray[2]);  
                                if ($myTime->between($fromTime, $toTime)){
                                    $dataactive=1;
                                }else{
                                    $dataactive=0;
                                } 
                            }
                            $row->is_active=$dataactive;
                        }
                        
                    }   
                }else{
                    $row->is_favorite=0;
                    $row->is_active=0;
                        
                }

                $getreview=Review::where('lawyer_id',$row->user_id)->count('id');
                $rating=Review::where('lawyer_id',$row->user_id)->avg('rating');
                // $row->is_active=0;
                $row->id=$row->user_id;
                $row->user_name=$user_name;
                $row->profile_img=$profile_img;
                $row->is_call=$row->is_call;
                $row->is_chat=$row->is_chat;
                $row->call_charge=$row->call_charge;
                $row->chat_charge=$row->chat_charge;
                $row->experience=$row->experience;
                $row->education_details=$row->education_details?$row->education_details:null;
                $row->language=$language;
                // $row->practice_area=$area;
                $row->practice_area=implode(',', $area);
                $row->practice_state=$state;
                $row->rating=round($rating,2);
                $row->total_review=$getreview;                
                $data[]=$row;
                unset($row->user_id);                
                // unset($row->average_rating);
            }
            
            return response()->json(["status" => 200,"success"=>true,"message"=>"Lawyer list by area",'data'=>$data]); 

        }else{
            return response()->json(["status" => 200,"success"=>ture,"message"=>"Data not found"]); 
        }
    }

    public function lawyerDetails($id=''){
        if($id!=''){
            $user=User::where(['id'=>$id,'is_verified'=>'1','user_type'=>'2'])->first();
        }else{
            return response()->json(['status' => 400,"success" => false,'message'=> "User not found"]);
        }
        if(!empty($user)){ 
            $userInfo['id'] = $user->id;
            $userInfo['phone'] = $user->phone;
            $userInfo['gender'] = $user->gender;                                  
            $userInfo['is_verified'] =(int)$user->is_verified; 
            $userInfo['profile_img'] = $user->profile_img ? imgUrl.'profile/'.trim(preg_replace('/\s+/','', $user->profile_img)):user_img;
            $userInfo['first_name'] = $user->first_name;
            $userInfo['last_name'] = $user->last_name;                
               
            $getLawyer=lawyerDetail::where('user_id',$id)->first();
            if(!empty($getLawyer)){

                $getarea=PracticeArea::select('name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $practice=[];
                if(count($getarea)){
                    // $practice=[];
                    foreach ($getarea as $value) {
                        array_push($practice,$value->name);
                    }
                }
                $getlanguage=Language::select('language_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $language=[];
                if(count($getlanguage)){
                    // $practice=[];
                    foreach ($getlanguage as $value) {
                        array_push($language,$value->language_name);
                    }
                }
                $getstate=State::select('state_name')->whereIn('id',json_decode($getLawyer->practice_area))->get();
                $state=[];
                if(count($getstate)){
                    // $practice=[];
                    foreach ($getstate as $value) {
                        array_push($state,$value->state_name);
                    }
                }
                $users=Auth::user();
                $userInfo['is_active']=0;
                if(!empty($users)){                
                    $fav=Favorite::where('status','1')->where('lawyer_id',$id)->where('user_id',$users->id)->first();
                   
                    if(!empty($fav)){
                        $userInfo['is_favorite']=1;
                    }else{
                        $userInfo['is_favorite']=0;
                    }
                    $utcTime = Carbon::now()->format('Y-m-d H:i:s');

                    $today = Carbon::now();
                    $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
                    $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
                    
                    $dayOfWeek = $today->dayOfWeek;
                    $checklawyer=Availability::where(['user_id'=>$id,'day_id'=>$dayOfWeek,'status'=>'1'])->first();
                    if(!empty($checklawyer)){
                       
                        $gettime=AvailabilityTime::where('availability_id',$checklawyer->id)->where('status','1')->get();
                        if(sizeof($gettime)){
                            foreach ($gettime as $value) {
                                $fromtimearray=explode(":", $value->from);
                                $totimearray=explode(":", $value->to);

                                $mytimeArray = explode(":", $todaytime);
                                
                                $toTime = Carbon::createFromTime($totimearray[0], $totimearray[1], $totimearray[2]);
                                $fromTime = Carbon::createFromTime($fromtimearray[0], $fromtimearray[1], $fromtimearray[2]);

                                $myTime = Carbon::createFromTime($mytimeArray[0], $mytimeArray[1], $mytimeArray[2]);
                                
                                if ($myTime->between($fromTime, $toTime)){
                                    $dataactive=1;
                                }else{
                                    $dataactive=0;
                                } 
                            }
                            $userInfo['is_active']=$dataactive;
                        }
                        
                    }
                }else{
                     $userInfo['is_favorite']=0;
                     $userInfo['is_active']=0;
                }
                $rating=Review::where('lawyer_id',$id)->avg('rating');
                $getreview=Review::where('lawyer_id',$id)->count('id');
                $language=implode(',',$language);
                $userInfo['education_details']=$getLawyer->education_details;
                $userInfo['experience']=$getLawyer->experience;                    
                $userInfo['description']=$getLawyer->description;
                $userInfo['ac_no']=$getLawyer->ac_no;
                $userInfo['ifsc']=$getLawyer->ifsc;
                $userInfo['account_name']=$getLawyer->account_name;
                $userInfo['chat_charge']=$getLawyer->chat_charge;
                $userInfo['is_chat']=$getLawyer->is_chat;
                $userInfo['call_charge']=$getLawyer->call_charge;
                $userInfo['is_call']=$getLawyer->is_call;
                $userInfo['language']=$language;
                $userInfo['practice_area']=$practice;
                $userInfo['practice_state']=$state;
                $userInfo['rating']=round($rating,2);
                $userInfo['total_review']=$getreview;
                $res=$this->checkavailability($id);
                $userInfo['availability']=$res;
                
            }
            
            return response()->json(['status' => 200,"success" => true,'message'=> "User Details",'data'=>$userInfo]);
        }else{
            return response()->json(['status' => 400,"success" => false,'message'=> "User not exist"]);
        }
    }
    

    public function getoffer($type=''){
        return response()->json(["status" => 200,"success"=>true,"message"=>"Offer image",'data'=>(array)default_img]);
    }
    
    public function checkavailability($id=''){          
            $today = Carbon::now();
            // $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
            // $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
            $dayOfWeek = $today->dayOfWeek;
            $currentDayName = Carbon::now()->format('l');
            
            $array=[];
            $array1=[]; 
            $array2=[]; 
            $avilability=Availability::select('id','day_id')->where(['user_id'=>$id])->get();
            if(sizeof($avilability)){                    
                foreach($avilability as $row){
                    $chekctime=AvailabilityTime::select('from','to')->where('availability_id', $row->id)->where('status','1')->get();
                    if(count($chekctime)){
                        $data=[];
                        foreach($chekctime as $val){
                            $val->from=Carbon::parse($val->from)->format('h:i A');
                            $val->to=Carbon::parse($val->to)->format('h:i A');
                            $data[]=$val;
                        }
                    }else{
                        $data=null;
                    }  
                    if($row->day_id==1){
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Monday";
                        }


                    }elseif($row->day_id==2){
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Tuesday";
                        }

                    }elseif($row->day_id==3){
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Wednesday";
                        }
                        
                    }elseif($row->day_id==4){
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Thursday";
                        }
                        
                    }elseif($row->day_id==5){
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Friday";
                        }
                        
                    }elseif($row->day_id==6){
                         if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Saturday";
                        }
                    }else{
                        if($dayOfWeek==$row->day_id){
                            $row->day="Today";
                        }else{
                            $row->day="Sunday";
                        }
                        
                    }                    
                                      
                    $row->time=$data;
                    $data1[]= $row;
                    unset($row->id);
                }                
                $array=$data1;
                $currentDayIndex = $dayOfWeek; // Get the numeric representation of the current day (1 for Monday, 7 for Sunday)

                
                $currentDayRecord = null;
                $otherDayRecords = [];

                foreach ($array as $record) {
                    if ($record['day_id'] === $currentDayIndex) {
                        $currentDayRecord = $record;
                    } else {
                        $otherDayRecords[] = $record;
                    }
                }

                if ($currentDayRecord !== null) {
                    array_unshift($otherDayRecords, $currentDayRecord);
                }
               return $otherDayRecords;
            }else{
                return $array;                    
            }
                        
        
    }

    public function lawyersByFiter(){
        // sort_by 1-relevence2-experinece high to low,3-price low to high,4-price high to low,5-popularity high to low,6-rating high to low,
        //  practice area
        // price range 1- 10-50,2-50-100,3-100-200,4-200-500.
        // price range 1- 10-50,2-50-100,3-100-200,4-200-500.

        $array1=['1','2','3','4'];
       
        $array2=['1','2','3'];
        $array3=['1','2','4'];
        $array4=['1','3','4'];
        $array5=['2','3','4'];

        $array7=['1','2'];
        $array8=['1','3'];
        $array9=['1','4',];

        
        $array10=['2','3'];
        $array11=['2','4'];
        $array12=['3','4'];

        $array13=['1'];
        $array14=['2'];
        $array15=['3'];
        $array16=['4'];

        if(in_array(['1','2','3','4'],$request->price)){
            // $min="10";
            // $max="50";

        }elseif(in_array(['1','2','3'],$request->price)){
            // $min="10";
            // $max="50";
        }elseif(in_array(['1','2','4'],$request->price)){
            
        }elseif(in_array(['1','3','4'],$request->price)){
            
        }elseif(in_array(['2','3','4'],$request->price)){
            
        }elseif(in_array(['1','2'],$request->price)){
            
        }elseif(in_array(['1','3'],$request->price)){
            
        }elseif(in_array(['1','4',],$request->price)){
            
        }elseif(in_array(['2','3'],$request->price)){
            
        }elseif(in_array(['2','4'],$request->price)){
            
        }elseif(in_array(['3','4'],$request->price)){
            
        }elseif(in_array(['1'],$request->price)){
            
        }elseif(in_array(['2'],$request->price)){
            
        }elseif(in_array(['3'],$request->price)){
            
        }elseif(in_array(['4'],$request->price)){
            
        }else{
        }
       
       

         if($type==1){
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            ->where('users.is_verified', 1)
            ->get();
        $msg="Premium Lawyer list";
        
        }elseif($type==2){

            
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')  
            ->where('users.is_verified', 1)
            ->get();
         $msg="Active Lawyer list";
        
        }elseif($type==3){
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            ->where('users.is_verified', 1)
            ->get();
    
         $msg="Family Lawyer list";
        }else{
            $lawyers = DB::table('lawyer_details')
            ->select('lawyer_details.user_id', 'lawyer_details.is_call','lawyer_details.is_chat','lawyer_details.call_charge','lawyer_details.chat_charge','lawyer_details.practice_area','lawyer_details.practice_state','lawyer_details.experience','lawyer_details.language')
            ->join('users', 'users.id', '=', 'lawyer_details.user_id')
            ->where('users.is_verified', 1)
            ->get();
             $msg="All Lawyer list";
        }

        if(sizeof($lawyers)){
            $data=[];
            foreach($lawyers as $row){
                $lawyerDetails=User::select('first_name','last_name','profile_img','city')->where('id',$row->user_id)->first();               
                if(!empty($lawyerDetails)){
                    $practice_area=json_decode($row->practice_area);
                    $areadata=[]; 
                    foreach($practice_area as $area){
                        $getarea=PracticeArea::select('name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->name;
                            $areadata[]=$area;
                        }
                    }
                    $practice_state=json_decode($row->practice_state);
                    $state=[]; 
                    foreach($practice_state as $area){
                        $getarea=State::select('state_name')->where('id',$area)->first();
                       
                        if(!empty($getarea)){
                            $area=$getarea->state_name;
                            $state[]=$area;
                        }
                    }
                    $languages=json_decode($row->language); 
                    $language_name=[]; 
                    foreach($languages as $language){
                        $getlanguage=Language::select('language_name')->where('id',$language)->first();
                        if(!empty($getlanguage)){
                            $language=$getlanguage->language_name;
                            $language_name[]=$language;
                        }
                        
                    }
                
                    $user_name=$lawyerDetails->first_name.' '.$lawyerDetails->last_name;
                    $city=$lawyerDetails->city;
                    $language1=implode(',',$language_name);
                    $language=$language1;
                    $area=$areadata;
                    $profile_img=$lawyerDetails->profile_img?imgUrl.'profile/'.$lawyerDetails->profile_img:user_img;
                }
                $user=Auth::user();
                if(!empty($user)){
                    $fav=Favorite::where('status','1')->where('lawyer_id',$row->user_id)->where('user_id',$user->id)->first();                   
                    if(!empty($fav)){
                        $row->is_favorite=1;
                    }else{
                        $row->is_favorite=0;
                    }
                    $utcTime = Carbon::now()->format('Y-m-d H:i:s');

                    $indiaTime = Carbon::createFromFormat('Y-m-d H:i:s', $utcTime, 'UTC')->setTimezone('Asia/Kolkata');
                    $today = Carbon::now();
                    $todaytime = Carbon::parse($indiaTime)->format('H:i:s');
                    
                    $dayOfWeek = $today->dayOfWeek;
                    $checklawyer=Availability::where(['user_id'=>$row->user_id,'day_id'=>$dayOfWeek,'status'=>'1'])->first();
                    if(!empty($checklawyer)){

                        $gettime=AvailabilityTime::where('availability_id',$checklawyer->id)->where('status','1')->get();
                        if(sizeof($gettime)){
                            foreach ($gettime as $value) {
                                $fromtimearray=explode(":", $value->from);
                                $totimearray=explode(":", $value->to);

                                $mytimeArray = explode(":", $todaytime);
                                // return $mytimeArray;
                                $toTime = Carbon::createFromTime($totimearray[0], $totimearray[1], $totimearray[2]);
                                $fromTime = Carbon::createFromTime($fromtimearray[0], $fromtimearray[1], $fromtimearray[2]);

                                $myTime = Carbon::createFromTime($mytimeArray[0], $mytimeArray[1], $mytimeArray[2]);
                                // echo  $toTime.'-----'.$fromTime.'----'.$myTime;// return $myTime;
                                
                                if ($myTime->between($fromTime, $toTime)){
                                    $dataactive=1;
                                }else{
                                    $dataactive=0;
                                } 
                            }
                            $row->is_active=$dataactive;
                        }
                        
                    }
                   

                }else{
                        $row->is_favorite=0;
                        
                }

                $getreview=Review::where('lawyer_id',$row->user_id)->count('id');
                $rating=Review::where('lawyer_id',$row->user_id)->avg('rating');
                // $row->is_active=0;
                $row->id=$row->user_id;
                $row->user_name=$user_name;
                $row->profile_img=$profile_img;
                $row->is_call=$row->is_call;
                $row->is_chat=$row->is_chat;
                $row->call_charge=$row->call_charge;
                $row->chat_charge=$row->chat_charge;
                $row->experience=$row->experience;
                $row->language=$language;
                $row->practice_area=$area;
                $row->practice_state=$state;
                $row->rating=round($rating,2);
                $row->total_review=$getreview;
                
                $data[]=$row;
                unset($row->user_id);                
                // unset($row->average_rating);
            }
            // return $data;
            return response()->json(["status" => 200,"success"=>true,"message"=>$msg,'data'=>$data]); 

        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You've to login first"]); 
        }
    }

}



