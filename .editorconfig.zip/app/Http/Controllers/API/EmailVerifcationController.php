<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Carbon\Carbon;
use App\Notifications\emailVerificationRequest;
use App\Notifications\emailVerificationSucess;
use App\Models\User;
use App\EmailVerification;
use Illuminate\Support\Str;
use Validator;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
class EmailVerifcationController extends ApiController
{
    /*we are using this create function from user regestration API so commented here and copy same code in usercontroller (which is running without auth) but if we need to send this again after auth we can use belove function (create)*/
    public function resendOTP(Request $request)
    {
        $data = json_decode($request->getContent(), true);
        $validator = Validator::make($data, [
            'email' => 'required|string|email',
        ]);
        if ($validator->fails()) {
            $status['error'] = $validator->errors();
            return response()->json($status, JsonResponse::HTTP_BAD_REQUEST);
        }

        $where = [['email', '=', $data['email']], ['status', '!=', 3]];
        $user = User::where($where)->first();
        // print_r($user); die();
        if (!$user) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_402')], JsonResponse::HTTP_BAD_REQUEST);
        }
 $token = mt_rand(1000, 9999);
        $verify = EmailVerification::updateOrCreate(
            ['email' => $user->email],
            [
                'email' => $user->email,
                'token' => $token,
            ]
        );
        if ($user && $verify) {
            $user->notify(new emailVerificationRequest($verify->token));
        }
        // $success['token'] =  $user->createToken('MyApp')-> accessToken; 
        // $success['name'] =  $user->name;
        header('authtoken:' . $user->createToken('MyApp')->accessToken);
        return response()->json(["message"=>trans('emailNotifications.success_message_email_verification'),"OTP"=>$token],JsonResponse::HTTP_OK); 
    }
    /**
     * Find token password reset
     *
     * @param  [string] $token
     * @return [string] message
     * @return [json] passwordReset object
     */
    public function find($token)
    {
        $verify = EmailVerification::where('token', $token)->first();
        if (!$verify) {
            return response()->json(['status' => '400', 'message' => 'This verification token is invalid.']);
        }
        if (
            Carbon::parse($verify->updated_at)
                ->addMinutes(1440)
                ->isPast()
        ) {
            $verify->delete();
            return response()->json(['status' => '400', 'message' => 'This verification token is invalid.']);
        }
        return response()->json($verify);
    }
    /**
     * Reset password
     *
     * @param  [string] email
     * @param  [string] password
     * @param  [string] password_confirmation
     * @param  [string] token
     * @return [string] message
     * @return [json] user object
     */
    public function confirm(Request $request)
    {
        // print_r($request->all()); die();
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            // 'veryfication' => 'required',
            // 'token' => 'required|string',
        ]);
        if ($validator->fails()) {
            // return response()->json(['message' => 'All fields with star are mandatory, please check and fill!!', 'error' => $validator->errors(), 'status' => 400]);
            // return redirect()->back()
            //           ->withErrors($validator)
            //           ->withInput();
            $message = '400';
            return redirect('/Verify_email/' . $request->token . '/' . base64_encode($request->current_lang) . '/' . base64_encode($request->email) . '/' . $message);
        }
        $verify = EmailVerification::where([['token', $request->token], ['email', $request->email]])->first();
        if (!$verify) {
            // return response()->json(
            //     [
            //         'message' => 'This password reset token or email is invalid.',
            //     ],
            //     404
            // );
            $message = '401';
            return redirect('/Verify_email/' . $request->token . '/' . base64_encode($request->current_lang) . '/' . base64_encode($request->email) . '/' . $message);
        }
        $where = [['email', '=', $verify->email], ['status', '!=', 3]];
        $user = User::where($where)->first();
        if (!$user) {
            // return response()->json(
            //     [
            //         'message' => "We can't find a user with that e-mail address.",
            //     ],
            //     404
            // );
            $message = '402';
            return redirect('/Verify_email/' . $request->token . '/' . base64_encode($request->current_lang) . '/' . base64_encode($request->email) . '/' . $message);
        }
        // $user->original_password = $request->password;
        $user->is_email_verified = $request->veryfication ? $request->veryfication : 1;
        $user->email_verified_at = strtotime(now());
        $user->save();
        $verify->delete();
        $user->notify(new emailVerificationSucess($verify));
        // $res = ['status'=>"200",'message'=>'Your password reset successfully! please click on login button for login page'];
        // return response()->json($res);
        // return response()->json($user);
        $message = '403';
        return redirect('/Verify_email/' . $request->token . '/' . base64_encode($request->current_lang) . '/' . base64_encode($request->email) . '/' . $message);
    }


    public function confirmWithOTP(Request $request)
    {
       if ($request->is_email == "1") {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'otp' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], JsonResponse::HTTP_BAD_REQUEST);
        }
        $verify = EmailVerification::where([['token', $request->otp], ['email', $request->email]])->first();
        if (!$verify) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_401')], JsonResponse::HTTP_BAD_REQUEST);
        }
        $where = [['email', '=', $verify->email], ['status', '!=', 3]];
        $user = User::where($where)->first();
        if (!$user) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_402')], JsonResponse::HTTP_BAD_REQUEST);
        }
        // $user->original_password = $request->password;
        // $user->is_email_verified = $request->veryfication ? $request->veryfication : 1;
        $user->is_email_verified = 1;
        $user->email_verified_at = strtotime(now());
        $user->save();
        $verify->delete();
        $user->notify(new emailVerificationSucess($verify));

        $user->authtoken = $user->createToken('MyApp')->accessToken;
        $user->profile = ($user->profile)?profile_url.$user->profile:profile_url.'defaultUser.png';
        $user->is_email_verified = ($user->is_email_verified)?strval($user->is_email_verified):'';
        return response()->json(['message' => trans('emailNotifications.email_verification_error_403'),"record"=>$user], JsonResponse::HTTP_OK);
        } 
        elseif ($request->is_email == "0") {
        // if registered with phone
            $validator = Validator::make($request->all(), [
            'email' => 'required|numeric',
            'otp' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], JsonResponse::HTTP_BAD_REQUEST);
        }
        $verify = EmailVerification::where([['token', $request->otp], ['phone', $request->email]])->first();
        if (!$verify) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_401')], JsonResponse::HTTP_BAD_REQUEST);
        }
        $where = [['phone', '=', $verify->phone], ['status', '!=', 3]];
        $user = User::where($where)->first();
        if (!$user) {
            return response()->json(['error' => trans('emailNotifications.phone_verification_error_402')], JsonResponse::HTTP_BAD_REQUEST);
        }
        // $user->original_password = $request->password;
        $user->is_phone_verified = 1;
        $user->phone_verified_at = strtotime(now());
        $user->save();
        $verify->delete();
        
         //getting token for sms otp form token api
        $authTokenSms = $this->token();

        $url = send_otp;
        // print_r($url); die();
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = ["Content-Type: application/x-www-form-urlencoded","Authorization: Bearer ".$authTokenSms];
        // print_r($headers); die();
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $data = "mobile_phone=".$user->phone."&message= Hi, ".trans('emailNotifications.phone_verification_success')."&from=4546";

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        //for debug only!
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $resp = curl_exec($curl);
        curl_close($curl);

        $user->authtoken = $user->createToken('MyApp')->accessToken;
        $user->profile = ($user->profile)?profile_url.$user->profile:profile_url.'defaultUser.png';
        $user->is_email_verified = ($user->is_email_verified)?strval($user->is_email_verified):'';
        return response()->json(['message' => trans('emailNotifications.email_verification_error_403'),"record"=>$user], JsonResponse::HTTP_OK);
        }
    }

        // return response()->json($res);

    // change email section sending OTP on new email and save it as temoporary email until verified

    public function changeEmailOTP(Request $request)
    {
        $loginUser = Auth::user();
         $data = json_decode($request->getContent(), true);
        // print_r($data['email']); die();
        $where = [['email', '=', $data['email']], ['status', '!=', 3]];
        $checkDeleted = User::select('id')
            ->where($where)
            ->get();
        
        // print_r($checkDeleted); die();
        $input = [];
        $input = $data;

     if (count($checkDeleted) > 0) {

        $validator = Validator::make($data,[ 
            'email' => 'required|email|unique:users,email', 
        ]);
    }
    else
    {
      $validator = Validator::make($data,[ 
            'email' => 'required|email', 
        ]);  
    }
        if ($validator->fails()) {
            $status['error'] = $validator->errors();
            return response()->json($status, JsonResponse::HTTP_BAD_REQUEST);
        }
        $where = [['email', '=', $loginUser->email], ['status', '!=', 3]];
        $user = User::where($where)->first();
       
        if (!$user) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_402')], JsonResponse::HTTP_BAD_REQUEST);
        }
        $updateEmail['temporary_email'] = $data['email'];
        $insert = User::where('id',$user->id)->update($updateEmail);
        // die();
        if($insert)
        {

        $token = mt_rand(1000, 9999);
        $verify = EmailVerification::updateOrCreate(
            ['email' => $user->temporary_email],
            [
                'email' => $user->temporary_email,
                'token' => $token,
            ]
        );
        if ($user && $verify) {
            $user->notify(new emailVerificationRequest($verify->token));
        }
        // $success['token'] =  $user->createToken('MyApp')-> accessToken; 
        // $success['name'] =  $user->name;
        header('authtoken:' . $user->createToken('MyApp')->accessToken);
        return response()->json(["message"=>trans('emailNotifications.success_message_change_email_verification'),"OTP"=>$token],JsonResponse::HTTP_OK); 
        }
         else
        {
            return response()->json(["error" => trans('customMessages.something_wrong')], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    // confirm new email

    public function confirmNewEmailWithOTP(Request $request)
    {
        // print_r($request->all()); die();
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'otp' => 'required|string',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], JsonResponse::HTTP_BAD_REQUEST);
        }
        $verify = EmailVerification::where([['token', $request->otp], ['email', $request->email]])->first();
        if (!$verify) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_401')], JsonResponse::HTTP_BAD_REQUEST);
        }
        $where = [['temporary_email', '=', $verify->email], ['status', '!=', 3]];
        $user = User::where($where)->first();
        if (!$user) {
            return response()->json(['error' => trans('emailNotifications.email_verification_error_402')], JsonResponse::HTTP_BAD_REQUEST);
        }
        // $user->original_password = $request->password;
        $user->is_email_verified = 1;
        $user->email = $request->email;
        $user->temporary_email = '';
        $user->email_verified_at = strtotime(now());
        $user->save();
        $verify->delete();
        $user->notify(new emailVerificationSucess($verify));

        $user->authtoken = $user->createToken('MyApp')->accessToken;
        $user->profile = ($user->profile)?profile_url.$user->profile:profile_url.'defaultUser.png';
        $user->is_email_verified = ($user->is_email_verified)?strval($user->is_email_verified):'';
        return response()->json(['message' => trans('emailNotifications.email_verification_error_403'),"record"=>$user], JsonResponse::HTTP_OK);
        // return response()->json($res);
    }


    // curl function to get sms otp

    public function token()
    {
        $url = sms_url;

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = ["Content-Type: application/x-www-form-urlencoded"];
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $data = "email=" . sms_email . "&password=" . sms_pass;

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        //for debug only!
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $resp = curl_exec($curl);
        curl_close($curl);
        $decodedData = json_decode($resp);
        $token = $decodedData->data->token;
        return $token;
    }
}
