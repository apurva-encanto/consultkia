<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;

use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Validator;
use Session;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Notification;
use App\Models\Appointment;
use App\Models\Ticketlist;
use App\Models\Slot;
use Illuminate\Http\JsonResponse;
// use Illuminate\Http\JsonResponse;
use App\helpers\Notifications;

class NotificationController extends ApiController

{
   public function __construct()
    {  
      Auth::shouldUse('api');
    }

    
    public function notify()
    {     
      $payload="bkjbdefjhvbhjbhjv";
      $name="bujivedglbgklrvfew";
      return send_notification1($payload,$name);
      
    }

    public function notificationlist(){
      //type 1-offer service,2-appointment request,3-appointment approved,4-appointment complete,5-payment successfull,6-appointment cancellation
        $user=Auth::user();
        if(!empty($user)){
          $updatecount=User::where('id',$user->id)->update([
            "notification_count"=>0
          ]);
          $getnotification=Notification::where('reciever_id',$user->id)->orderBy('id','desc')->paginate(10);
          
          // return$user;
          if(count($getnotification) > 0){
              foreach($getnotification as $row){
                $name='';
                $profile='';
                $getuser=User::where('id',$row->sender_id)->first();
                if(!empty($getuser)){
                  $name=$getuser->name;
                  $profile=$getuser->profile_img?imgUrl.'user_profile/'.$getuser->profile_img:default_img;
                }
                $date='';
                $stime='';
                $etime='';
                $sid='';
                $status='';

                $getappinment=Appointment::where('id',$row->appointment_id)->first();
                if(!empty($getappinment)){

                  $date=$getappinment->date;

                  $slot1=Slot::where('id',$getappinment->slot_id)->first();
                  // return $slot;
                  if(!empty($slot1)){
                    $stime=$slot1->start_time;
                    $etime=$slot1->end_time;
                    $sid=$getappinment->slot_id;
                    if($slot1->end_time!=''){
                      $status=true;
                    }else{
                      $status=false;
                    }
                    
                  }
                }
                if($sid==null){
                  $slot=null;
                }else{
                  $slot['id']=(int)$sid;
                  $slot['fromTime']=$stime;
                  $slot['toTime']=$etime;
                  $slot['status']=$status;
                }
                if($row->type==1){
                  $type="New Offer";
                }elseif($row->type==2){
                  $type="New appointment request";
                }elseif($row->type==3){
                  $type="Appointment has approved from RVN";
                }elseif($row->type==4){
                  $type="New Offer";
                }else{
                  $type="New Offer";
                }

                if($row->type==14){
                  $getticketnumber=Ticketlist::where('id',$row->appointment_id)->first();
                  $getticketimage=null;
                  if($getticketnumber->is_file==1){
                      $getticketimage=Ticketlistimage::where('ticket_id',$row->appointment_id)->first();
                      $getticketimage=$getticketimage->image?imgUrl.'Ticket'.$getticketimage->image:null;
                  }
                  $othersdata=array(
                          "id"=>(int)$row->id,
                          'ticket_id'=>(string)$row->appointment_id,
                          'user_id'=>$user->id,
                          'subject'=>$getticketnumber->subject?$getticketnumber->subject:null,
                          'discription'=>$getticketnumber->discription?$getticketnumber->discription:null,
                          'status'=>$getticketnumber->status?(string)$getticketnumber->status:'0',
                          'created_at'=>$getticketnumber->created_at,
                          'updated_at'=>$getticketnumber->updated_at,
                          'image'=>$getticketimage
                      );
                  $row->otherMiscData=json_encode($othersdata);
                }
                $row->name=$name;
                $row->sender_id=(int)$row->sender_id;
                $row->reciever_id=(int)$row->reciever_id;
                $row->appointment_id=(int)$row->appointment_id;
                $row->appointment_date=$date;
                $row->status=(int)$row->status;
                $row->type=(int)$row->type;
                $row->user_profile=$profile;
                $row->type_msg=$type;                
                $row->notification_status=(int)$row->notification_status;
                if($row->type!=14){
                  $row->slot=$slot;
                }                
                $data[]=$row;
                unset($row->status);
                unset($row->created_at);
                unset($row->response);
                unset($row->updated_at);

              }

                $getarray1['status']= 200;
                $getarray1['success']= true;
                $getarray1['message']="Notifications list";
                $getarray1['data']=!empty($data)?$data:array();
                $getarray1['currentPage'] = $getnotification->currentPage();
                $getarray1['last_page'] = $getnotification->lastPage();
                $getarray1['total_record'] = $getnotification->total();
                $getarray1['per_page'] = $getnotification->perPage();
              return response()->json($getarray1);
          }else{
                $getarray1['status']= 200;
                $getarray1['success']= true;
                $getarray1['message']="";
                $getarray1['data']=array();
                $getarray1['currentPage'] = $getnotification->currentPage();
                $getarray1['last_page'] = $getnotification->lastPage();
                $getarray1['total_record'] = $getnotification->total();
                $getarray1['per_page'] = $getnotification->perPage();
              return response()->json($getarray1);
             
          }
        }else{
          return response()->json(['status'=>400,'success'=>false,'message'=>"You've not logged In. Please Login first to get access this"]);
        }
    
    }

    public function notificationCount(){
        $user=Auth::user();
        if(!empty($user)){
          $count=Notification::where('reciever_id',$user->id)->where('status','0')->count('id');
          if($count > 0){
            return response()->json(['status'=>200,'success'=>true,'message'=>"You've " .$count ." new notifications","data"=>$count]);
          }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"You've no new notifications"]);
          }
        }else{
          return response()->json(['status'=>400,'success'=>false,'message'=>"You've not logged In. Please Login first to access this"]);
        }
    
    }

    public function notificationDelete(){
        $user=Auth::user();
        if(!empty($user)){
          $delete=Notification::where('reciever_id',$user->id)->delete();
          if($delete==true){
            return response()->json(['status'=>200,'success'=>true,'message'=>"All notifications has been deleted"]);
          }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"failed try again"]);
          }
        }else{
          return response()->json(['status'=>400,'success'=>false,'message'=>"You've not logged In. Please Login first to get access this"]);
        }
    
    }
 
}
 
