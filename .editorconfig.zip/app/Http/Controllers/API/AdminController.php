<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Validator;
use Session;
use Response;
use Auth;
use Mail;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Blog;
use App\Models\State;
use App\Models\Court;
use App\Models\Language;
use App\Models\PracticeArea;
use App\Models\GuideLine;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;

class AdminController extends ApiController
{
    public function __construct()
    {
        // return "hello";
        Auth::shouldUse('api');
    }

    
    // add/edit subadmin
    public function addEditState(Request $request){                
        $validator = Validator::make($request->all(), [
            'state_name' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
        }
        if($user->user_type==3){
            if($request->id!=''){
                $state=State::find($request->id); 
                $msg="State Successfully Updated";
            }else{
                $state=new State ();
                $msg="State Successfully Added";
            }
            $state->state_name=$request->state_name;
            $query=$state->save();
            if($query=true){
                return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"Something went wrong try again"]);
            }
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized"]);
        }

    }
    public function stateList(){
        $state=State::select('id','state_name')->get();
        if(sizeof($state)){
            return response()->json(['status'=>200,'success'=>true,'message'=>"State List","data"=>$state]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"State not found"]);
        }

    }


    public function addEditCourt(Request $request){                
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
        }
        $user=Auth::user();
        if($user->user_type==3){
            if($request->id!=''){
                $court=Court::find($request->id); 
                $msg="Court Successfully Updated";
            }else{
                $court=new Court ();
                $msg="Court Successfully Added";
            }
            $court->name=$request->name;
            $query=$court->save();
            if($query=true){
                return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"Something went wrong try again"]);
            }
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized"]);
        }

    }

    public function courtList(){
        $court=Court::select('id','name')->get();
        if(sizeof($court)){
            return response()->json(['status'=>200,'success'=>true,'message'=>"Court List","data"=>$court]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Court not found"]);
        }

    }

    public function addEditLanguage(Request $request){ 
        $validator = Validator::make($request->all(), [
            'language_name' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
        }
        $user=Auth::user();               
        if($user->user_type==3){
            if($request->id!=''){
                $Language=Language::find($request->id); 
                $msg="Language Successfully Updated";
            }else{
                $Language=new Language ();
                $msg="Language Successfully Added";
            }
            $Language->language_name=$request->language_name;
            $query=$Language->save();
            if($query=true){
                return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"Something went wrong try again"]);
            }
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized !"]);
        }
        

    }

    public function languageList(){
        $Language=Language::select('id','language_name')->get();
        if(sizeof($Language)){
            return response()->json(['status'=>200,'success'=>true,'message'=>"Language List","data"=>$Language]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Language not found"]);
        }

    }

    public function addEditPractice(Request $request){                
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
        }
        $user=Auth::user();               
        // if($user->user_type==3){
            if($request->id!=''){
                $practice=PracticeArea::find($request->id); 
                $msg="Practice Area Successfully Updated";
            }else{
                $practice=new PracticeArea ();
                $msg="Practice Area Successfully Added";
            }
            
            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $filename = time() . '.' . $file->extension();
                $file->move(storage_path('app/public/practice'), $filename); // Move to the correct directory
                
                $practice->image=$filename;
            }
            $practice->name=$request->name;
            $query=$practice->save();
            if($query=true){
                return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"Something went wrong try again"]);
            }
        // }else{
        //     return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized !"]);
        // }

    }

    public function practiceList(){
        $practice=PracticeArea::select('id','name','image')->get();
        if(sizeof($practice)){
            foreach($practice as $row){
                $row->image= $row->image?imgUrl.'practice/'.$row->image:default_img;
                $data[]=$row;  
            }
            return response()->json(['status'=>200,'success'=>true,'message'=>"Practice Area List","data"=>$data]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Data not found"]);
        }

    }

    public function addEditBlog(Request $request){                
        $validator = Validator::make($request->all(), [
            'title' => 'required',
            'description' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
        }
        $user=Auth::user();               
        if($user->user_type==3){
            if($request->id!=''){
                $practice=Blog::find($request->id); 
                $msg="BlogSuccessfully Updated";
            }else{
                $practice=new Blog();
                $msg="Blog Successfully Added";
            }
            if($request->hasFile('image')) {
                $file = $request->file('image');
                $filename = time() . '_' . $file->getClientOriginalName();
                $file->move(storage_path('app/public/blog/', $filename)); 
                $filename = trim(preg_replace('/\s+/','', $filename));
                $practice->image=$filename;
            }  
            $practice->title=$request->title;
            $practice->description=$request->description;
            $query=$practice->save();
            if($query=true){
                return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"Something went wrong try again"]);
            }
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized !"]);
        }

    }

    public function blogList(){
        $practice=Blog::select('id','title','description','image','created_at')->get();
        if(sizeof($practice)){
            foreach($practice as $row){
                $row->image= $row->image?imgUrl.'blog/'.$row->image:default_img;
                
               
                $formattedDate = Carbon::parse($row->created_at)->format('M-d-Y');
                $row->created=$formattedDate;
                $data[]=$row;  
                unset($row->created_at);
            }
            // return $data
            return response()->json(['status'=>200,'success'=>true,'message'=>"Blog List","data"=>$data]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Data not found"]);
        }

    }


    public function blogDetails($id=''){
        if($id!=''){
            $blog=Blog::select('id','title','description','image','created_at')->where('id',$id)->first();
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Bolg not found"]);
        }
        if(!empty($blog)){            
                $formattedDate = Carbon::parse($blog->created_at)->format('M-d-Y');
                $array['id']=$id;
                $array['title']=$blog->title;
                $array['description']=$blog->description;
                $array['created']=$formattedDate;
                $array['image']= $blog->image?imgUrl.'blog/'.$blog->image:default_img;                
            return response()->json(['status'=>200,'success'=>true,'message'=>"Blog List","data"=>$array]);
        }else{
            return response()->json(['status'=>400,'success'=>false,'message'=>"Data not found"]);
        }

    }
     
    
        public function addSplash(Request $request){
            // type 1-splash,2-helpus,3-reminder
            // is_default 1-active,0-inactive
            $validator = Validator::make($request->all(),[
                "image"=> 'required|image|mimes:jpeg,png,jpg,svg|max:2048',
                "type"  => 'required',
                "is_default"  => 'required', 
            ]);

            if($validator->fails()){
                return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
            }
            $user=Auth::user();
            if($user->user_type==3){        
              $check=Splash::where('type',$request->type)->get();

              if(count($check) > 0){
                // return "data found";
                        if($request->is_default==1){
                            $updateDefault=Splash::where('is_default','1')->where('type',$request->type)->update(['is_default'=>'0']);
                        }
                        $imageName = time().'.'.$request->image->extension();     
                        $request->image->move(storage_path('app/public/Splash'), $imageName);
                        $splash=new Splash();
                        $splash->image=$imageName;
                        $splash->type=$request->type;
                        $splash->is_default=$request->is_default;
                        $query=$splash->save();
                        if($query==true){
                            if($request->type==1){
                                $msg="Splash";
                            }elseif($request->type==2){
                                $msg="Help Us";
                            }else{
                                $msg="Reminder";
                            }

                            return response()->json(['status'=>200,'success'=>true,"message"=>$msg.' '." added successfully"]);
                        }else{
                            return response()->json(['status'=>400,'success'=>false,"message"=>$msg.' '."has not been add,try again"]);
                        }
              }else{
                    // return "data not found";
                    if($request->hasfile('image')){
                        $imageName = time().'.'.$request->image->extension();     
                        $request->image->move(storage_path('app/public/Splash'), $imageName); 

                        $splash=new Splash();
                        $splash->image=$imageName;
                        $splash->type=$request->type;
                        $splash->is_default='1';
                        $query=$splash->save();
                        if($query==true){
                            if($request->type==1){
                                $msg="Splash ";
                            }elseif($request->type==2){
                                $msg="Help Us ";
                            }else{
                                $msg="Reminder ";
                            }
                            return response()->json(['status'=>200,'success'=>true,"message"=>$msg ." successfully added"]);
                        }else{
                            return response()->json(['status'=>400,'success'=>false,"message"=>$msg," Can't add,try again"]);
                        }
                       
                    }
              }
            
            }else{
                return response()->json(['status'=>400,'success'=>false,"message"=>"You're not authorized "]);
            }     
           
        
        }

    // delete splash here
        public function deleteSplash(Request $request){
            // type 1-splash,2-helpus,3-reminder
            // is_default 1-active,0-inactive
            $validator = Validator::make($request->all(),[
                "id"=> 'required'           
            ]);

            if($validator->fails()){
                return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
            }
            $user=Auth::user();
            if($user->user_type==3){        
              $check=Splash::where('id',$request->id)->first();
              if(!empty($check)){
                $checkdefault=Splash::where('type',$check->type)->where('id','!=',$request->id)->first();
                if(!empty($checkdefault)){
                    $setdefault=Splash::where('id',$checkdefault->id)->where('id','!=',$request->id)->update([
                    "is_default"=>'1'
                ]);
                    $path=storage_path("app/public/Splash/".$check->image);
                    unlink($path);
                    $delete=Splash::where('id',$request->id)->delete();
                }else{
                    $path=storage_path("app/public/Splash/".$check->image);
                    unlink($path);
                    $delete=Splash::where('id',$request->id)->delete();
                }            
                
              }
            }else{
                return response()->json(['status'=>400,'success'=>false,"message"=>"You're not authorized "]);
            }     
        
        }
    // all splash list here
        public function splashlist(Request $request){
            $user=Auth::user();
            if($user->user_type==3){
                $validator = Validator::make($request->all(),[
                   "type"  => 'required',               
                ]);
                if($validator->fails()){
                    return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
                }
                if($request->type==1){
                    $splash=Splash::select('id','image','is_default','type')->where('type','1')->get();
                    if(sizeof($splash)){
                        foreach($splash as $row){
                            $row->images=$row->image?imgUrl.'Splash/'.$row->image:default_img;
                            $data[]=$row;
                            unset($row->image);
                        }
                    }else{
                        $data=[];
                    }
                    
                }elseif($request->type==2){
                    $helpus=Splash::select('id','image','is_default','type')->where('type','2')->get();
                    if(sizeof($helpus)){
                        foreach($helpus as $row){
                            $row->images=$row->image?imgUrl.'Splash/'.$row->image:default_img;
                            $data[]=$row;
                            unset($row->image);
                        }
                    }else{
                        $data=[];
                    }
                
                }else{
                  $reminder=Splash::select('id','image','is_default','type')->where('type','3')->get();
                     if(sizeof($reminder)){
                        foreach($reminder as $row){
                            $row->images=$row->image?imgUrl.'Splash/'.$row->image:default_img;
                            $data[]=$row;
                            unset($row->image);
                        }
                    }else{
                        $data=[];
                    } 
                }
                if(count($data)>0){
                    
                    return response()->json(["status" => 200,"success" => true, "message" =>"",'data'=>$data]);
                }else{
                    return response()->json(["status" => 400,"success" => false, "message" =>"data not found"]);
                }
                
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized !"]);
            }
        
        }

    // splash end here

    // guideline section 

    // add/edit terms privacy refund and faq's 
        public function addQuidelines(Request $request){        
            // type 1-terms & condition, 2-Privacy Policy,3-Faq,else Refund policy
            if($request->type==1){
                $validator = Validator::make($request->all(), [
                    'description' => 'required',
                    'type'=>'required'
                ]);
            }elseif($request->type==2){
                $validator = Validator::make($request->all(), [
                    'description' => 'required',
                    'type'=>'required'
                ]);
            }elseif($request->type==3){
                $validator = Validator::make($request->all(), [
                    'title' => 'required',
                    'description' => 'required',
                    'type'=>'required'
                ]);
            }else{
                $validator = Validator::make($request->all(), [
                    'description' => 'required',
                    'type'=>'required'
                ]);
            }

            if($validator->fails()){
                return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
            }

            $user=Auth::user();
            if($user->user_type=='3'){
                
                if($request->type=='1'){               
                    if($request->id !=''){                
                        $quide=GuideLine::find($request->id);
                        if($quide->type==3){
                            $guide->title=$request->title;
                            $msg="Faq Successfully Updated";
                        }elseif($request->type==2){
                            $msg="Privacy Policy Successfully Updated";
                        }elseif($request->type==1){
                            $msg="Terms & Condition Successfully Updated";
                        }else{
                            $msg="Refund Policy Successfully Updated";
                        }
                        $quide->description=$request->description;
                        $save=$quide->save();
                        if($save==true){
                            return response()->json(['status'=>200,'success'=>true,'message'=>"Terms & Condition successfully updated"]);
                        }else{
                            return response()->json(['status'=>400,'success'=>false,'message'=>"failed try again"]);
                        }
                    }else{                
                        $quide=new GuideLine();
                        if($request->type==3){
                            $guide->title=$request->title;
                            $msg="Faq Successfully Added";
                        }elseif($request->type==2){
                            $msg="Privacy Policy Successfully Added";
                        }elseif($request->type==1){
                            $msg="Terms & Condition Successfully Added";
                        }else{
                            $msg="Refund Policy Successfully Added";
                        }
                        $quide->description=$request->description;
                        $save=$quide->save();
                        if($save==true){
                            return response()->json(['status'=>200,'success'=>true,'message'=>$msg]);
                        }else{
                            return response()->json(['status'=>400,'success'=>false,'message'=>"failed try again"]);
                        }
                    }

                 }    
                
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized"]);
            }
        
        }

    //  faq delete here
        public function faqdelete(Request $request){

            $validator = Validator::make($request->all(), [
                'id' => 'required',
                
            ]);
            if($validator->fails()){
                return response()->json(["status" => 400,"success" => false, "message" => $validator->messages()->first()]);
            }
            $user=Auth::user();
            if($user->user_type=="3"){
                $faq=GuideLine::where('id',$request->id)->delete();
                if($faq==true){
                    return response()->json(['status'=>200,'success'=>true,'message'=>"Faq successfully deleted"]);
                }else{
                    return response()->json(['status'=>400,'success'=>false,'message'=>"Faq not deleted try again"]);
                }
            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"You're not authorized"]);
            }
        
        }

    //  all guidence list

        public function guidelines($usertype='',$type=''){
            // type 1-terms & condition, 2-Privacy Policy,3-Faq,else Refund policy
            if($type!=''){
                if($type==1){
                    $guideline=GuideLine::select('id','description','created_at','updated_at')->where('type','1')->first();
                    $msg="Terms & Condition";
                }elseif($type==2){
                    $guideline=GuideLine::select('id','description','created_at','updated_at')->where('type','2')->first();
                    $msg="Privacy Policy";
                }elseif($type==3){
                    $guideline=[];
                    if($usertype=='1'){
                        $faq=GuideLine::select('id','title','description','faq_for','created_at','updated_at')->whereIn('faq_for',['1','0'])->where('type','3')->orderBy('id','asc')->get();
                    }else{
                        $faq=GuideLine::select('id','title','description','faq_for','created_at','updated_at')->whereIn('faq_for',['2','0'])->where('type','3')->orderBy('id','asc')->get();
                    } 
                    if(sizeof($faq)){
                        foreach($faq as $row){
                        $guideline[]=$row;
                        }
                    }  
                    $msg="Faq";                 
                }else{
                    $guideline=GuideLine::select('id','description','created_at','updated_at')->where('type','4')->first();
                    $msg="Refund policy";
                }
                if($guideline){
                    return response()->json(['status'=>200,'success'=>true,'message'=>$msg,'data'=>$guideline]);
                }else{
                    return response()->json(['status'=>400,'success'=>false,'message'=>$msg .' '.'Data not found']);
                }

            }else{
                return response()->json(['status'=>400,'success'=>false,'message'=>"failed try again"]);
            }  
        
        }
        
        public function updateSequencing(Request $request)
        {
            // type 1- for practice area sequencing
            $user = Auth::User()->id;
            $data = json_decode($request->getContent(), true);
            $validator = Validator::make($data, [
                'allData' => 'required',
                "type"=>"required"
            ]);

            if ($validator->fails()) {
                return response()->json(['message' => $validator->errors()->first(), 'status' => false]);
            }
            $allData = $request->allData;
            $i = 0;
            // return $request->allData;

            foreach ($allData as $record) {            
                $i++;   
                if($request->type==1){
                    $query = PracticeArea::where('id', $record)->update(['position' => $i]);
                }        
                           
            }

            if($query) {
                return response()->json(["status" => 200,"success" => true, "message" => "Faq squence update successfull."]);
            } else {
                return response()->json(["status" => 400,"success" => false, "message" => "Faq squence update fail!"]);
            }
        }

       


}
