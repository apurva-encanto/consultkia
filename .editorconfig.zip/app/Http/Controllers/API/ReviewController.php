<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Validator;
use Session;
use Auth;
use Twilio\Rest\Client;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Rate;
use App\Models\Pet;
use App\Models\Review;

class ReviewController extends ApiController
{
    public function __construct(){
        Auth::shouldUse('api');
    }

    public function reviewlist(Request $request){    
        $validator = Validator::make($request->all(), [ 
            'lawyer_id' => 'required',   
            "sort_by"=>"required",
            "rating"=>""
         ]);
        if($validator->fails()){
            return response()->json(["status" => 407,"success" => false,"message" => $validator->errors()->first()]);
        }   

        if($request->sort_by=='1'){
            if($request->rating!=''){
                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id,'rating'=>$request->rating])->orderby('rating','desc')->paginate('8');
            }else{

                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id])->orderby('rating','desc')->paginate('8');
            }
        }elseif($request->sort_by=='2'){
            if($request->rating!=''){
                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id,'rating'=>$request->rating])->orderby('rating','asc')->paginate('8');
            }else{

                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id])->orderby('rating','asc')->paginate('8');
            }
        }elseif($request->sort_by=='3'){
             if($request->rating!=''){
                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id,'rating'=>$request->rating])->orderby('id','asc')->paginate('8');
                }else{

                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id])->orderby('id','asc')->paginate('8');
            }
        }elseif($request->sort_by=='4'){
             if($request->rating!=''){
                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id,'rating'=>$request->rating])->orderby('id','desc')->paginate('8');
                }else{

                $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id])->orderby('id','desc')->paginate('8');
            }

        }else{
            $review = Review::with('userDetail')->select('id','lawyer_id','user_id','rating','description')->where(['lawyer_id'=>$request->lawyer_id,'rating'=>$request->rating])->orWhere(['lawyer_id'=>$request->lawyer_id,'rating'=>0])->orderby('id','desc')->paginate('8');
        }
                
        if(sizeof($review)){            
            foreach($review  as $row){                           
                $row->id=$row->id;
                $row->user_id=$row->user_id;
                $row->user_name=$row->userDetail->user_name;
                $row->user_profile=$row->userDetail->profile_img?imgUrl.'user_profile/'.$row->userDetail->profile_img:user_img;
                $row->description=$row->description;
                $row->rating=$row->rating?$row->rating:0;
                $data[]=$row;   
                unset($row->userDetail);
            }
            $finalData['status'] = 200;
            $finalData['success'] = true;
            $finalData['message'] ="Reviews list";
            $finalData['data'] =!empty($data)?$data:array();
            $finalData['currentPage'] = $review->currentPage();
            $finalData['last_page'] = $review->lastPage();
            $finalData['total_record'] = $review->total();
            $finalData['per_page'] = $review->perPage();
            return response($finalData);
            // return response()->json(['status' => 200,'success' => true, 'message' =>"Reviews list",'data'=>$data]);                   
        }else{     
                $finalData['status'] = 200;
                $finalData['success'] = true;
                $finalData['message'] ="Reviews not found";
                $finalData['data'] =[];
                $finalData['currentPage'] = 1;
                $finalData['last_page'] = 1;
                $finalData['total_record'] = 0;
                $finalData['per_page'] = "8";
                return response($finalData);       
            // return response()->json(['status' => 400,'success' => false, 'message'=>"No data found"]);
        }
    }

    public function addReview(Request $request){ 
        $validator = Validator::make($request->all(), [ 
           'lawyer_id' => 'required',   
           "description"=>"",
           "rating"=>""
        ]);
        if($validator->fails()){
            return response()->json(["status" => 400,"success" => false,"message" => $validator->errors()->first()]);
        }   

        $user=Auth::user();       
        $review=new Review();
        $review->lawyer_id=$request->lawyer_id;
        $review->user_id=$user->id;
        $review->rating=$request->description?$request->description:null;
        $review->date=Carbon::now();
        $review->description=$request->rating?$request->rating:0;
        $query=$review->save();
        if($query){
            return response()->json(['status' => 200,'success' => true, 'message' =>"Your review has been submitted !"]);
        }else{
            return response()->json(['status' => 400,'success' => false, 'message'=>"Failed try again"]);
        }   
    }
    
    public function myReviews(){
        $user=Auth::user();
        if($user->user_type==2){
            $getallReviews=Review::select('id','user_id','rating','description')->with('userDetail')->where('lawyer_id',$user->id)->orderbydesc('id')->paginate(8);        
            if(sizeof($getallReviews)){            
                foreach($getallReviews  as $row){                           
                    $row->id=$row->id;
                    $row->user_id=$row->user_id;
                    $row->user_name=$row->userDetail->user_name;
                    $row->user_profile=$row->userDetail->profile_img?imgUrl.'user_profile/'.$row->userDetail->profile_img:user_img;
                    $row->description=$row->description;
                    $row->rating=$row->rating?$row->rating:0;
                    $data[]=$row;   
                    unset($row->userDetail);
                }
                $finalData['status'] = 200;
                $finalData['success'] = true;
                $finalData['message'] ="My Reviews list";
                $finalData['data'] =!empty($data)?$data:array();
                $finalData['currentPage'] = $getallReviews->currentPage();
                $finalData['last_page'] = $getallReviews->lastPage();
                $finalData['total_record'] = $getallReviews->total();
                $finalData['per_page'] = $getallReviews->perPage();
                return response($finalData);
                                  
            }else{     
                    $finalData['status'] = 200;
                    $finalData['success'] = true;
                    $finalData['message'] ="Reviews not found";
                    $finalData['data'] =[];
                    $finalData['currentPage'] = 1;
                    $finalData['last_page'] = 1;
                    $finalData['total_record'] = 0;
                    $finalData['per_page'] = "8";
                    return response($finalData);       
                // return response()->json(['status' => 400,'success' => false, 'message'=>"No data found"]);
            }
        }else{
            return response()->json(["status" => 400,"success"=>false,"message"=>"You're not authorized"]);
        }

    }
   
}
