<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\EmailVerification;
use App\Notifications\emailVerificationRequest;
use App\Notifications\emailVerificationSucess;
use Illuminate\Http\JsonResponse;
use App\Models\PasswordReset;
use App\Notifications\PasswordResetRequest;
use App\Notifications\PasswordResetSuccess;
use Validator;
use Session;
use Auth;
use Storage;
use Twilio\Rest\Client;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Payment;
use App\Models\LawyerDetail;
use App\Models\PracticeArea;
use App\Models\Document;
use App\Models\Language;
use App\Models\Review;
use App\Models\Appointment;
use App\Models\Favorite;
use App\Models\Splash;
use App\Models\Order;
use App\Notifications\SignupNotification;



class OrderController extends ApiController
{
    public function __construct()
    {
        Auth::shouldUse('api');

    }

    public function getAllOrders($type=''){
    	if($type!=''){
    		$orders=Order::with('userDetails')->where('lawyeer_id',$user->id)->groupBy('user_id')->orderBydesc('id')->limit('5')->get();
    		$msg="Latest Call/Chat list";
    	}else{
    		$orders=Order::with('userDetails')->where('lawyeer_id',$user->id)->orderBydesc('id')->get();
    		$msg="All Order List";
    	}
    	$user=Auth::user();
    	if($user->user_type==2){

	    	if(sizeof($orders)){
	    		foreach ($variable as $row) {
					$row->user_name=$user->userDetails->username?$user->userDetails->username:null;
					$row->city=$user->userDetails->city?$user->userDetails->city:null;
					$row->phone=$user->userDetails->phone?$user->userDetails->phone:null;
					// $row->case=$user->userDetails->phone?$user->userDetails->phone:null;
					if($row->call_type==1){
						$row->call_type="Call";
					}else{
						$row->call_type="Chat";
					}
					$row->deduction=$row->total_amount;
					$row->call_rate=$row->call_rate;
					$row->date=Carbon::parse($row->created_at)->format('M-d-Y');
					$row->profile_img=$user->userDetails->profile_img?imgUrl.'profile/'.$user->userDetails->profile_img:user_img;
					$data[]=$row;
					unset($userDetails);
					unset($row->created_at);
					unset($row->total_amount);
	    		}
	    		return response()->json(["status" => 200, "success"=> true, "message" =>$ms,'data'=>$data]);

	    	}else{
	    		return response()->json(["status" => 400, "success"=> false, "message" =>"Data not found !"]);
	    	}
    	}else{
	    	return response()->json(["status" => 400, "success"=> false, "message" =>"You're not authorized!"]);

    	}

    }

    public function addCallRecord(Request $request){
        if($request->id!=''){
                $validator = Validator::make($request->all(),[
                'id' => 'required',  
                'duration'=>'',
                'call_start'=>'',
                'call_end'=>'',
                
                ]);
        }else{
            $validator = Validator::make($request->all(),[
                // 'user_id' => 'required', 
                'lawyer_id'=>'required',
                'call_initiate'=>''
                
            ]); 
        }
		
        if($validator->fails()){
            return response()->json(["status" => 400, "success"=> false, "message" => $validator->messages()->first()]);
        }

        $user=Auth::user();
        if(!empty($user)){
            $getrate=LawyerDetail::select('call_charge')->where('user_id',$request->lawyer_id)->first();
                if(!empty($getrate)){
                    $getrate=$getrate->call_charge;
                }else{
                    $getrate=null;
                }
            if($request->id!=''){
                $order=Order::find($request->id);
                $time=Carbon::now()->format('Y-m-d H:i');
                $utcDatetime = Carbon::createFromFormat('Y-m-d H:i',$time, 'UTC');
                $istDatetime = $utcDatetime->setTimezone('Asia/Kolkata');
                $time=Carbon::parse($istDatetime)->format('Y-m-d H:i:s');
                if($order->call_start==null){
                    $time=Carbon::now()->format('Y-m-d H:i');
                    $utcDatetime = Carbon::createFromFormat('Y-m-d H:i',$time, 'UTC');
                    $istDatetime = $utcDatetime->setTimezone('Asia/Kolkata');
                    $time=Carbon::parse($istDatetime)->format('Y-m-d H:i');
                    $order->call_start=$time;
                }
                if($order->call_start!=null){
                    $time=Carbon::now()->format('Y-m-d H:i');
                    $utcDatetime = Carbon::createFromFormat('Y-m-d H:i',$time, 'UTC');
                    $istDatetime = $utcDatetime->setTimezone('Asia/Kolkata');
                    $time=Carbon::parse($istDatetime)->format('Y-m-d H:i:s');
                    $order->call_end=$time;                    
                }
                if($request->duration > 0){
                    if($request->duration>0){
                        $duration=$request->duration/60;
                        $seconds=$request->duration;
                        $minutes = floor($seconds / 60);
                        $remainingSeconds = $seconds % 60;

                        $formattedTime = sprintf("%d:%02d", $minutes, $remainingSeconds);
                        $order->duration=$request->duration?$formattedTime:null;
                    }
                    // return $formattedTime;
                    $amount=ceil($duration)*$getrate;
                    if ($request->hasFile('file')) {
                        $file = $request->file('file');
                        $filename = time() . '.' . $file->extension();
                        $file->move(storage_path('app/public/recordings/'), $filename); // Move to the correct directory
                        
                        $order->file=$filename;
                    }
                   
                    $order->total_amount=$amount?$amount:0;
                }                
                
                $query=$order->save();
                $msg="Order Successfully updated";
            }else{

                
                $time=Carbon::now()->format('Y-m-d H:i:s');
                $utcDatetime = Carbon::createFromFormat('Y-m-d H:i:s',$time, 'UTC');
                $istDatetime = $utcDatetime->setTimezone('Asia/Kolkata');

                $time=Carbon::parse($istDatetime)->format('Y-m-d H:i:s');
                // return $time;
                $order=new Order();
                $order->user_id=$user->id;
                $order->lawyer_id=$request->lawyer_id;
                $order->call_initiate=$time;
                $order->call_rate=$getrate;
                $order->call_start=$request->call_start?$request->call_start:null;
                $order->call_end=$request->call_end?$request->call_end:null;
                $order->duration=$request->duration?$request->duration:null;
                $query=$order->save();
                $msg="Order Successfully created";
            }
            if($query==1){
                return response()->json(["status" => 200, "success"=> true, "message" =>$msg,'data'=>$order]);
            }else{
                return response()->json(["status" => 400, "success"=> false, "message" =>"failed try again"]);  
            }
        }else{
            return response()->json(["status" => 400, "success"=> false, "message" =>"Need to login first"]);
        }
    }

    public function getCallhistory(){
        $user=Auth::user();
        if($user->user_type==1){
            $orders=Order::with('lawyerDetails')->where('user_id',$user->id)->orderBydesc('id')->get();
            if(sizeof($orders)){
                foreach ($orders as $row) {
                    $chekrating=Review::where(['lawyer_id'=>$row->lawyer_id])->avg('rating');
                    $chekfav=Favorite::where(['user_id'=>$user->id,'lawyer_id'=>$row->lawyer_id,'status'=>'1'])->first();
                    $is_fav=0;
                    if(!empty($chekfav)){
                        $is_fav=1;
                    }
                    $row->user_name=$row->lawyerDetails->user_name?$row->lawyerDetails->user_name:null;
                    $row->first_name=$row->lawyerDetails->first_name?$row->lawyerDetails->first_name:null;
                    $row->last_name=$row->lawyerDetails->last_name?$row->lawyerDetails->last_name:null;
                    if($row->call_type==1){
                        $row->call_type="Call";
                    }else{
                        $row->call_type="Chat";
                    }
                    $row->deduction=$row->total_amount;
                    $row->call_rate=$row->call_rate;
                    $row->is_fav=$is_fav;
                    $row->rating=round($chekrating,2);
                    $row->date=Carbon::parse($row->created_at)->format('M-d-Y');
                    $row->profile_img=$row->lawyerDetails->profile_img?imgUrl.'profile/'.$row->lawyerDetails->profile_img:user_img;
                    $data[]=$row;
                    unset($row->lawyerDetails);
                    unset($row->created_at);
                    unset($row->total_amount);
                    unset($row->user_id);
                }
                return response()->json(["status" => 200, "success"=> true, "message" =>"All call history",'data'=>$data]);

            }else{
                return response()->json(["status" => 400, "success"=> false, "message" =>"Data not found !"]);
            }
        }else{
            return response()->json(["status" => 400, "success"=> false, "message" =>"You're not authorized!"]);

        }

    }

    public function callDetail($id=''){
        $user=Auth::user();
        if($user->user_type==1){
            $orders=DB::table('orders')->select('orders.file','users.city','users.first_name','users.last_name','users.user_name','users.gender','lawyer_details.practice_area','lawyer_details.experience','users.gender','orders.lawyer_id','lawyer_details.language')
            ->join('users','users.id','orders.lawyer_id')
            ->join('lawyer_details','lawyer_details.user_id','orders.lawyer_id')
            
            ->where('orders.id',$id)
            ->first();
            // return $orders;
            if(!empty($orders)){
                $getarea=PracticeArea::select('name')->whereIn('id',json_decode($orders->practice_area))->get();
                    $practice=[];
                    if(count($getarea)){
                        // $practice=[];
                        foreach ($getarea as $value) {
                            array_push($practice,$value->name);
                        }
                    }
                    $getlanguage=Language::select('language_name')->whereIn('id',json_decode($orders->language))->get();
                    $language=[];
                    if(count($getlanguage)){
                       
                        foreach ($getlanguage as $value) {
                            array_push($language,$value->language_name);
                        }
                    }
                $chekfav=Favorite::where(['user_id'=>$user->id,'lawyer_id'=>$orders->lawyer_id,'status'=>'1'])->first();
                $is_fav=0;
                if(!empty($chekfav)){
                    $is_fav=1;
                }
               
                $array['user_name']=$orders->lawyer_id;
                $array['lawyer_id']=$orders->first_name.' '.$orders->last_name;
               
                if($orders->gender==1){
                $array['gender']="Male";
                }elseif($orders->gender==2){
                $array['gender']="Female";
                }else{
                $array['gender']="Others";

                }
                $array['experience']=$orders->experience;
                $array['is_fav']=$is_fav;
                $array['file']=$orders->file?imgUrl.'recordings/'.$orders->file:null;
                $array['city']=$orders->city;
                $array['specialization']=implode(',',$practice);
                $array['language']=implode(',',$language);
                // $array=[];
                return response()->json(["status" => 200, "success"=> true, "message" =>"Call Details",'data'=>$array]);

            }else{
                return response()->json(["status" => 400, "success"=> false, "message" =>"Data not found !"]);
            }
        }else{
            return response()->json(["status" => 400, "success"=> false, "message" =>"You're not authorized!"]);

        }

    }
}
