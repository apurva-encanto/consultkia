<?php

use App\models\Production;

if(!function_exists("get_Formatted_date")){
    function get_Formatted_date($date,$format){
        $formattedDate=date($format,strtotime($date));
        return $formattedDate;
    }
}




?>