<?php

// sms otp details
// define('sms_url', 'notify.eskiz.uz/api/auth/login');
// define('send_otp', 'notify.eskiz.uz/api/message/sms/send');
// define('sms_email', 'anvarsafarov@hotmail.com');
// define('sms_pass', 'aAwd59nlOYJpfAI1YwG7lEAzmQWvuMSDZcjjJBMN');

define('now', strtotime(date('d-m-Y h:i A')));
define('imgUrl', 'https://consultkiya.encantotech.in/storage/app/public/');
define('user_img', 'https://consultkiya.encantotech.in/storage/app/public/user_default.png');
define('default_img', 'https://consultkiya.encantotech.in/storage/app/public/default.png');

//FCM toten
// define('FCM_KEY', 'AAAAQr6ufqI:APA91bE0xY3_Be2bqbLAW-VfYrXqcuSwW4Md_QFv5fX8JaRGqdVyjpwC7yEUXQcvn-8e9LdCnNNWrqizLrSUdJ6r9psITaereuCwt7j0O0mc8PWDFa-5RcCrJfOnvQFJ7IAYw8N804TS');
define('FCM_KEY', 'AAAAHtxB9Bo:APA91bEfWscfeUuQYyd4Sw7JnY_j-oLAnlAWMtbafu9ikXCnzfxi_rlw1LUt4pPsPQzm5hHbrp3h8ufLd7XORrQPIn204COSsTBLRhZL3eLBQh8IztoWhC7iqOMAxGBhbYvPDrZSb5Bv');

define('SID','AC81e89cf6e91eb32d34fb5c700ff5fbe0');
define('TOKEN','5c34923aa392ca780de363a89d83f064');
define('NUMBER','+12264065718');
?>

