<?php
use App\Models\User;
// use Auth;
use Carbon\Carbon;

    function send_notification2($fcm_token,$payload,$info = []){
      // die();
        $URL = 'https://fcm.googleapis.com/fcm/send';
        // $fcm_token = "fwGXXeV5T2eRWen78b9igt:APA91bEJ7Bz3mIt_qaq_J7Ruhy5qEx6sUTvWBVi3PFx8MolEoQ4b5hY99LorJ0NDRwdrD3OYhwA48eL3_JQC6UkG_3HLEEyDBbYH-lcq4taD8lHTBglMMFZhe3D04kTmp4nJKjpRba1L";
        $fcm_token = "fwGXXeV5T2eRWen78b9igt:APA91bEJ7Bz3mIt_qaq_J7Ruhy5qEx6sUTvWBVi3PFx8MolEoQ4b5hY99LorJ0NDRwdrD3OYhwA48eL3_JQC6UkG_3HLEEyDBbYH-lcq4taD8lHTBglMMFZhe3D04kTmp4nJKjpRba1L";
        $payload = array('title'=>"Please Renew before expire your plan",
                          'body'=> 'Your subscription plan will expire on',
                          'reference_id' => '14',
                          'type' => 1,
                          'type_for' => 1,
                          'sound'=>'default');

        $post_data = [
            'registration_ids' => array($fcm_token), //firebase token array
            'data' => $payload, //msg for andriod
            'notification' => $payload, //msg for ios

        ]; 
        $crl = curl_init();
        $headr = [];
        $headr[] = 'Content-type: application/json';
        // $headr[] = 'Authorization: key=AIzaSyAZzOsOFmY1w0FivAp1Y4zaW6nPUa8nBmY';
        
        $headr[] = 'Authorization: key='.FCM_KEY;
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);
        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);

        $rest = curl_exec($crl);
        curl_close($crl);
        return $rest;

    }


    function send_notification1($fcm_token, $data, $info) {
        // update notification count
        $count=0;
        $user = User::where('fcm_token', $fcm_token)->first();
        $updatecount=User::where('id',$user->id)->update([
            "notification_count"=>$user->notification_count+1,
        ]);
        if($updatecount==true){
            $getcount=User::select('notification_count')->where('fcm_token', $fcm_token)->first();
            $count=$getcount?$getcount->notification_count:0;
        }
        $URL = 'https://fcm.googleapis.com/fcm/send';
        $payload = $data;
        $a=$data;
        $b=["badge"=>$count];
        $c=array_merge($a,$b);
        $post_data = [
        'to' => $fcm_token, 
        'notification' => [

                "title" => $data['title'],
                "body" => $data['body'],
                "mutable_content"=> true,
                "sound"=> "Tri-tone",
                "badge"=>(int)$count,
                
            ],
        'data' => $c,
        'content_available' => true
        ];    
       
        $crl = curl_init();
        $headr = [];
        $headr[] = 'Content-type: application/json';
        $headr[] = 'Authorization: key='.FCM_KEY; 
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);
        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
        $rest = curl_exec($crl);
        curl_close($crl);   
        return $rest;
   
    }



    function send_notification3($fcm_token, $title, $body, $refrence_id, $data){
        $URL = 'https://fcm.googleapis.com/fcm/send';
        $payload = $data;
        $post_data = [
        'to' => $fcm_token, 
        'notification' => [
                "title" => $title,
                "body" => $body,
                "mutable_content"=> true,
                "sound"=> "Tri-tone"
            ],
        'data' => [
            "title"=> $title,
            "body"=> $body,
            'data' => $data,
            "reference_id" => $refrence_id
            ],
        ];    
        $crl = curl_init();
        $headr = [];
        $headr[] = 'Content-type: application/json';
        $headr[] = 'Authorization: key='.FCM_KEY; 
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);
        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
        $rest = curl_exec($crl);
        curl_close($crl);   
        return $rest;
    }
    
    function send_notification4($fcm_token, $data, $info){
        $URL = 'https://fcm.googleapis.com/fcm/send';
        $payload = $data;
        $post_data = [
        'to' => $fcm_token, 
        'notification' => [
                "title" => $data['title'],
                "body" => $data['body'],
                "mutable_content"=> true,
                "sound"=> "Tri-tone"
            ],
        'data' => $data,
        ];    
        // print_r(json_encode($post_data));
        // die;
        $crl = curl_init();
        $headr = [];
        $headr[] = 'Content-type: application/json';
        $headr[] = 'Authorization: key='.FCM_KEY; 
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);
        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
        $rest = curl_exec($crl);
        curl_close($crl);   
        return $rest;
    }

    function get_Formatted_date($date,$format)
    {
        $formattedDate=date($format,strtotime($date));
        return $formattedDate;
    }


    function rvn_signup_notification($fcm_token, $payload, $info = [])
    {
      // print_r($fcm_token); die;
      //print_r($title); print_r($body);  print_r($type) print_r($sender); print_r($receiver);
      // die();
        $URL = 'https://fcm.googleapis.com/fcm/send';
        $post_data = [
          'registration_ids' => $fcm_token, //firebase token array
          'data' => $payload, //msg for andriod
          'notification' => $payload, //msg for ios
        ];

        $crl = curl_init();
        $headr = [];
        $headr[] = 'Content-type: application/json';
        $headr[] = 'Authorization: key='.FCM_KEY;
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);
        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
        $rest = curl_exec($crl);
        curl_close($crl);
        $insert['sender_id'] = array_key_exists('sender_id', $info) ? $info['sender_id'] : '';
        $insert['reciever_id'] = array_key_exists('reciever_id', $info) ? $info['reciever_id'] : '';
        $insert['response'] = json_encode($payload);
        $insert['tokens'] = json_encode($fcm_token);
        $insert['fcm_response'] = $rest;
        //$insert['event_type'] = array_key_exists('event_type ', $info) ? $info['event_type '] : '';
        $query = DB::table('notifications')->insert($insert);
        return $rest;
    }//End rvn_signup_notification

?>